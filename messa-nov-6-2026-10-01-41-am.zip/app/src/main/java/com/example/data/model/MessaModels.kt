package com.example.data.model

data class User(
    val id: String,
    val name: String,
    val username: String,
    val bio: String,
    val avatarRes: Int? = null,
    val avatarUrl: String? = null,
    val coverRes: Int? = null,
    val coverUrl: String? = null,
    val followersCount: Int = 0,
    val followingCount: Int = 0,
    val isVerified: Boolean = false,
    val isFollowing: Boolean = false,
    val isOnline: Boolean = false,
    val website: String = "https://messa.social",
    val badges: List<String> = emptyList()
)

data class Story(
    val id: String,
    val userId: String,
    val userName: String,
    val userUsername: String,
    val userAvatarRes: Int? = null,
    val mediaRes: Int? = null,
    val caption: String = "",
    val timeAgo: String = "Just now",
    val isViewed: Boolean = false,
    val viewersCount: Int = 142,
    val viewers: List<User> = emptyList()
)

data class Comment(
    val id: String,
    val postId: String,
    val userId: String,
    val userName: String,
    val userUsername: String,
    val userAvatarRes: Int? = null,
    val content: String,
    val timeAgo: String = "Just now",
    val likesCount: Int = 0,
    val isLiked: Boolean = false,
    val replies: List<Comment> = emptyList()
)

data class Post(
    val id: String,
    val userId: String,
    val userName: String,
    val userUsername: String,
    val userAvatarRes: Int? = null,
    val isVerified: Boolean = false,
    val content: String,
    val mediaRes: Int? = null,
    val mediaType: MediaType = MediaType.NONE,
    val likesCount: Int = 0,
    val commentsCount: Int = 0,
    val sharesCount: Int = 0,
    val isLiked: Boolean = false,
    val isSaved: Boolean = false,
    val isFollowing: Boolean = false,
    val timeAgo: String = "Just now",
    val tags: List<String> = emptyList(),
    val comments: List<Comment> = emptyList()
)

enum class MediaType {
    NONE, IMAGE, VIDEO
}

data class Clip(
    val id: String,
    val userId: String,
    val userName: String,
    val userUsername: String,
    val userAvatarRes: Int? = null,
    val videoCoverRes: Int? = null,
    val title: String,
    val description: String,
    val soundTrack: String = "Original Sound - MESSA Beats",
    val likesCount: Int = 0,
    val commentsCount: Int = 0,
    val sharesCount: Int = 0,
    val isLiked: Boolean = false,
    val isFollowing: Boolean = false,
    val tags: List<String> = emptyList()
)

data class Message(
    val id: String,
    val senderId: String,
    val text: String,
    val time: String,
    val isSentByMe: Boolean,
    val isRead: Boolean = true,
    val isVoice: Boolean = false,
    val voiceDurationSec: Int = 0
)

data class Conversation(
    val id: String,
    val user: User,
    val lastMessage: Message,
    val unreadCount: Int = 0,
    val messages: List<Message> = emptyList()
)

data class Group(
    val id: String,
    val name: String,
    val description: String,
    val category: String,
    val avatarRes: Int? = null,
    val coverRes: Int? = null,
    val membersCount: Int = 0,
    val isPrivate: Boolean = false,
    val isJoined: Boolean = false,
    val rules: List<String> = emptyList(),
    val posts: List<Post> = emptyList()
)

data class NotificationItem(
    val id: String,
    val type: NotificationType,
    val title: String,
    val message: String,
    val timeAgo: String,
    val isRead: Boolean = false,
    val userAvatarRes: Int? = null
)

enum class NotificationType {
    LIKE, COMMENT, FOLLOW, MENTION, SYSTEM
}

data class AISuggestion(
    val id: String,
    val title: String,
    val content: String,
    val tags: List<String>
)

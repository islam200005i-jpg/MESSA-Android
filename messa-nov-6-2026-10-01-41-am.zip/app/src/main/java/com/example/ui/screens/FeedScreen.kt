package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Post
import com.example.data.model.Story
import com.example.data.model.User
import com.example.ui.components.StoryAvatarRing
import com.example.ui.theme.*

@Composable
fun FeedScreen(
    currentUser: User,
    stories: List<Story>,
    posts: List<Post>,
    isArabic: Boolean = false,
    onStoryClick: (Story) -> Unit,
    onAddStoryClick: () -> Unit,
    onNewPostClick: () -> Unit,
    onLikePost: (String) -> Unit,
    onSavePost: (String) -> Unit,
    onAddComment: (String, String) -> Unit,
    onFollowUser: (String) -> Unit,
    onDeletePost: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var quickCommentTexts by remember { mutableStateOf(mapOf<String, String>()) }
    var activeCommentsPostId by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBlack)
            .testTag("feed_screen"),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        // 1. Quick Post Creator Header
        item {
            QuickPostBar(
                user = currentUser,
                isArabic = isArabic,
                onClick = onNewPostClick
            )
        }

        // 2. Stories Carousel
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("stories_row"),
                    contentPadding = PaddingValues(horizontal = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Current User Add Story
                    item {
                        StoryAvatarRing(
                            avatarRes = currentUser.avatarRes,
                            name = if (isArabic) "قصتك" else "Your Story",
                            isViewed = false,
                            isMe = true,
                            onClick = onAddStoryClick
                        )
                    }

                    // Friends' Stories
                    items(stories) { story ->
                        if (story.userId != currentUser.id) {
                            StoryAvatarRing(
                                avatarRes = story.userAvatarRes,
                                name = story.userName,
                                isViewed = story.isViewed,
                                isMe = false,
                                onClick = { onStoryClick(story) }
                            )
                        }
                    }
                }
                Divider(
                    color = DarkSurfaceBorder.copy(alpha = 0.4f),
                    thickness = 0.8.dp,
                    modifier = Modifier.padding(top = 10.dp)
                )
            }
        }

        // 3. Posts Stream
        items(posts, key = { it.id }) { post ->
            PostCard(
                post = post,
                currentUserId = currentUser.id,
                isArabic = isArabic,
                quickCommentText = quickCommentTexts[post.id] ?: "",
                onQuickCommentChange = { text ->
                    quickCommentTexts = quickCommentTexts + (post.id to text)
                },
                onSendQuickComment = {
                    val text = quickCommentTexts[post.id].orEmpty()
                    if (text.isNotBlank()) {
                        onAddComment(post.id, text)
                        quickCommentTexts = quickCommentTexts + (post.id to "")
                    }
                },
                isCommentsExpanded = activeCommentsPostId == post.id,
                onToggleComments = {
                    activeCommentsPostId = if (activeCommentsPostId == post.id) null else post.id
                },
                onLikeClick = { onLikePost(post.id) },
                onSaveClick = { onSavePost(post.id) },
                onFollowClick = { onFollowUser(post.userId) },
                onDeleteClick = { onDeletePost(post.id) }
            )
        }
    }
}

@Composable
private fun QuickPostBar(
    user: User,
    isArabic: Boolean,
    onClick: () -> Unit
) {
    Surface(
        color = DarkSurface,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .testTag("quick_post_bar")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .border(1.dp, NeonPurple, CircleShape)
            ) {
                Image(
                    painter = painterResource(id = user.avatarRes ?: R.drawable.messa_logo),
                    contentDescription = user.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(DarkSurfaceElevated)
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Text(
                    text = if (isArabic) "ماذا يدور في ذهنك؟ انشر فكرة أو وسائط..." else "What's on your mind? Share text, clips, photos...",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    maxLines = 1
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            IconButton(
                onClick = onClick,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Image,
                    contentDescription = "Attach Media",
                    tint = NeonCyanBright
                )
            }
        }
    }
}

@Composable
fun PostCard(
    post: Post,
    currentUserId: String,
    isArabic: Boolean,
    quickCommentText: String,
    onQuickCommentChange: (String) -> Unit,
    onSendQuickComment: () -> Unit,
    isCommentsExpanded: Boolean,
    onToggleComments: () -> Unit,
    onLikeClick: () -> Unit,
    onSaveClick: () -> Unit,
    onFollowClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }

    Card(
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .border(1.dp, DarkSurfaceBorder.copy(alpha = 0.8f), RoundedCornerShape(18.dp))
            .testTag("post_card_${post.id}")
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .border(1.5.dp, Brush.horizontalGradient(listOf(NeonPurple, NeonCyan)), CircleShape)
                    ) {
                        Image(
                            painter = painterResource(id = post.userAvatarRes ?: R.drawable.messa_logo),
                            contentDescription = post.userName,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = post.userName,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = PureWhite
                            )
                            if (post.isVerified) {
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "Verified",
                                    tint = NeonCyanBright,
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "@${post.userUsername}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                            Text(
                                text = " • ${post.timeAgo}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextTertiary
                            )
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (post.userId != currentUserId) {
                        OutlinedButton(
                            onClick = onFollowClick,
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.height(30.dp),
                            shape = RoundedCornerShape(12.dp),
                            border = ButtonDefaults.outlinedButtonBorder.copy(
                                brush = if (post.isFollowing)
                                    Brush.horizontalGradient(listOf(DarkSurfaceBorder, DarkSurfaceBorder))
                                else
                                    Brush.horizontalGradient(listOf(NeonPurple, NeonCyan))
                            )
                        ) {
                            Text(
                                text = if (post.isFollowing) (if (isArabic) "متابَع" else "Following") else (if (isArabic) "متابعة" else "Follow"),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (post.isFollowing) TextSecondary else PureWhite
                            )
                        }
                    }

                    Box {
                        IconButton(onClick = { showMenu = true }, modifier = Modifier.size(34.dp)) {
                            Icon(Icons.Default.MoreVert, contentDescription = "Options", tint = TextSecondary)
                        }
                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false },
                            modifier = Modifier.background(DarkSurfaceElevated)
                        ) {
                            DropdownMenuItem(
                                text = { Text(if (isArabic) "نسخ الرابط" else "Copy Link", color = PureWhite) },
                                onClick = { showMenu = false }
                            )
                            DropdownMenuItem(
                                text = { Text(if (isArabic) "إبلاغ عن المنشور" else "Report Post", color = ErrorRed) },
                                onClick = { showMenu = false }
                            )
                            if (post.userId == currentUserId) {
                                DropdownMenuItem(
                                    text = { Text(if (isArabic) "حذف المنشور" else "Delete Post", color = ErrorRed) },
                                    onClick = {
                                        showMenu = false
                                        onDeleteClick()
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // Content text
            Text(
                text = post.content,
                style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 22.sp),
                color = PureWhite,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp)
            )

            // Tags
            if (post.tags.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    post.tags.take(4).forEach { tag ->
                        Text(
                            text = tag,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = NeonCyanBright
                        )
                    }
                }
            }

            // Media Preview if present
            if (post.mediaRes != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(260.dp)
                        .background(CyberBlack)
                ) {
                    Image(
                        painter = painterResource(id = post.mediaRes),
                        contentDescription = "Post Media",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            // Reaction Action Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Like button
                    IconButton(onClick = onLikeClick, modifier = Modifier.size(38.dp).testTag("like_button_${post.id}")) {
                        Icon(
                            imageVector = if (post.isLiked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                            contentDescription = "Like",
                            tint = if (post.isLiked) LikeRed else PureWhite,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Text(
                        text = "${post.likesCount}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (post.isLiked) LikeRed else TextSecondary
                    )

                    Spacer(modifier = Modifier.width(16.dp))

                    // Comment button
                    IconButton(onClick = onToggleComments, modifier = Modifier.size(38.dp).testTag("comment_button_${post.id}")) {
                        Icon(
                            imageVector = Icons.Outlined.ChatBubbleOutline,
                            contentDescription = "Comments",
                            tint = PureWhite,
                            modifier = Modifier.size(21.dp)
                        )
                    }
                    Text(
                        text = "${post.commentsCount}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.width(16.dp))

                    // Share button
                    IconButton(onClick = { /* Share */ }, modifier = Modifier.size(38.dp).testTag("share_button_${post.id}")) {
                        Icon(
                            imageVector = Icons.Outlined.Share,
                            contentDescription = "Share",
                            tint = PureWhite,
                            modifier = Modifier.size(21.dp)
                        )
                    }
                    Text(
                        text = "${post.sharesCount}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextSecondary
                    )
                }

                // Bookmark / Save
                IconButton(onClick = onSaveClick, modifier = Modifier.size(38.dp).testTag("save_button_${post.id}")) {
                    Icon(
                        imageVector = if (post.isSaved) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                        contentDescription = "Save",
                        tint = if (post.isSaved) NeonPurpleGlow else TextSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            // Comments Section (Animated expansion)
            AnimatedVisibility(visible = isCommentsExpanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkSurfaceElevated.copy(alpha = 0.6f))
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Text(
                        text = if (isArabic) "التعليقات (${post.comments.size})" else "Comments (${post.comments.size})",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = NeonCyanBright
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    if (post.comments.isEmpty()) {
                        Text(
                            text = if (isArabic) "كن أول من يعلق على هذا المنشور! ⚡" else "Be the first to comment on this post! ⚡",
                            fontSize = 12.sp,
                            color = TextTertiary,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    } else {
                        post.comments.forEach { comment ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                ) {
                                    Image(
                                        painter = painterResource(id = comment.userAvatarRes ?: R.drawable.messa_logo),
                                        contentDescription = comment.userName,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = comment.userName,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = PureWhite
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = comment.timeAgo,
                                            fontSize = 10.sp,
                                            color = TextTertiary
                                        )
                                    }
                                    Text(
                                        text = comment.content,
                                        fontSize = 12.sp,
                                        color = TextPrimary
                                    )
                                }
                            }
                        }
                    }

                    // Quick Comment input
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = quickCommentText,
                            onValueChange = onQuickCommentChange,
                            placeholder = { Text(if (isArabic) "اكتب تعليقاً..." else "Add a comment...", fontSize = 12.sp, color = TextTertiary) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(20.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonCyanBright,
                                unfocusedBorderColor = DarkSurfaceBorder,
                                focusedTextColor = PureWhite,
                                unfocusedTextColor = PureWhite,
                                focusedContainerColor = DarkSurface,
                                unfocusedContainerColor = DarkSurface
                            ),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(
                            onClick = onSendQuickComment,
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(MessaGradient)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Send,
                                contentDescription = "Send Comment",
                                tint = PureWhite,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

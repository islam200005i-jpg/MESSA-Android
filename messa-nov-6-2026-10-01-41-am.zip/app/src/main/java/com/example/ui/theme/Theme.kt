package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.graphics.Color
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val MessaDarkColorScheme = darkColorScheme(
    primary = NeonPurple,
    onPrimary = CyberBlack,
    primaryContainer = Color(0xFF3B1D66),
    onPrimaryContainer = NeonCyanBright,
    secondary = ElectricBlue,
    onSecondary = PureWhite,
    secondaryContainer = Color(0xFF1E3A8A),
    onSecondaryContainer = PureWhite,
    tertiary = NeonCyan,
    onTertiary = CyberBlack,
    tertiaryContainer = Color(0xFF0E4A5C),
    onTertiaryContainer = PureWhite,
    background = CyberBlack,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = DarkSurfaceBorder,
    error = ErrorRed,
    onError = PureWhite
)

@Composable
fun MessaTheme(
    darkTheme: Boolean = true, // Futuristic dark neon by default for MESSA
    content: @Composable () -> Unit
) {
    val colorScheme = MessaDarkColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            window?.let {
                val controller = WindowCompat.getInsetsController(it, view)
                controller.isAppearanceLightStatusBars = false
                controller.isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

// Backward compatibility alias
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MessaTheme(darkTheme = darkTheme, content = content)
}

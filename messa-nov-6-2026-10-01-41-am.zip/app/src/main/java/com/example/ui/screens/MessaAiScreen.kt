package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.AISuggestion
import com.example.ui.components.NeonGradientButton
import com.example.ui.theme.*

@Composable
fun MessaAiScreen(
    aiSuggestions: List<AISuggestion>,
    isGenerating: Boolean,
    generatedDraft: AISuggestion?,
    isArabic: Boolean = false,
    onBack: () -> Unit,
    onGenerate: (String) -> Unit,
    onApplyToPost: (String, List<String>) -> Unit
) {
    BackHandler { onBack() }

    var promptInput by remember { mutableStateOf("") }

    val presetPrompts = listOf(
        if (isArabic) "صياغة منشور فيروسي عن الذكاء الاصطناعي والمستقبل" else "Draft a viral post about AI & future networks",
        if (isArabic) "اقتراح وسوم وهاشتاجات قوية لفيديو Clips تقني" else "Suggest high-reach hashtags for a tech clip",
        if (isArabic) "كتابة وصف إبداعي لمعرض صور Cyberpunk 3D" else "Write creative caption for a 3D cyberpunk artwork",
        if (isArabic) "صياغة سؤال تفاعلي يجذب أكبر عدد من التعليقات" else "Draft an engaging question to boost comments"
    )

    Scaffold(
        topBar = {
            Surface(color = CyberBlack, modifier = Modifier.statusBarsPadding()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("ai_screen_back")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = PureWhite)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .border(1.dp, NeonPurpleGlow, CircleShape)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.messa_logo),
                            contentDescription = "MESSA AI",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "MESSA AI",
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                color = PureWhite
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(NeonPurple.copy(alpha = 0.25f))
                                    .padding(horizontal = 5.dp, vertical = 2.dp)
                            ) {
                                Text("INTELLIGENT", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = NeonCyanBright)
                            }
                        }
                        Text(
                            text = if (isArabic) "المساعد الذكي لمنصة التواصل العالمية" else "Intelligent Social Network Assistant",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }
            }
        },
        containerColor = CyberBlack
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .testTag("messa_ai_content"),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Engine status banner
            item {
                Surface(
                    color = DarkSurface,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, NeonPurple.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(NeonCyanBright)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = if (isArabic) "محرك MESSA AI جاهز ومتصل" else "MESSA AI Engine Active",
                                fontWeight = FontWeight.Bold,
                                color = PureWhite,
                                fontSize = 13.sp
                            )
                            Text(
                                text = if (isArabic) "يساعدك في كتابة المنشورات، اقتراح الوسوم، تحليل الصور والتفاعل الذكي" else "Helps draft viral posts, hashtag generation, and smart audience reach",
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }

            // Prompt Input Card
            item {
                Surface(
                    color = DarkSurface,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = if (isArabic) "ما الذي تريد من MESSA AI إنجازه؟" else "What do you want MESSA AI to create?",
                            fontWeight = FontWeight.Bold,
                            color = PureWhite,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = promptInput,
                            onValueChange = { promptInput = it },
                            placeholder = { Text(if (isArabic) "اكتب فكرة منشور، استفسار أو طلب هاشتاجات..." else "Type an idea, request hashtags or caption rewrite...", color = TextSecondary, fontSize = 13.sp) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 100.dp)
                                .testTag("ai_prompt_field"),
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonCyanBright,
                                unfocusedBorderColor = DarkSurfaceBorder,
                                focusedTextColor = PureWhite,
                                unfocusedTextColor = PureWhite,
                                focusedContainerColor = CyberBlack,
                                unfocusedContainerColor = CyberBlack
                            )
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        NeonGradientButton(
                            text = if (isGenerating) (if (isArabic) "جاري التحليل والتوليد..." else "Synthesizing...") else (if (isArabic) "توليد الذكاء الاصطناعي ⚡" else "Generate with AI ⚡"),
                            icon = Icons.Default.AutoAwesome,
                            onClick = {
                                if (promptInput.isNotBlank()) {
                                    onGenerate(promptInput)
                                }
                            },
                            enabled = !isGenerating && promptInput.isNotBlank(),
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "ai_generate_button"
                        )
                    }
                }
            }

            // Quick Prompt Ideas
            item {
                Column {
                    Text(
                        text = if (isArabic) "أفكار سريعة للاستخدام:" else "Quick Prompt Ideas:",
                        fontWeight = FontWeight.Bold,
                        color = PureWhite,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    presetPrompts.forEach { prompt ->
                        Surface(
                            color = DarkSurfaceElevated,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clickable {
                                    promptInput = prompt
                                    onGenerate(prompt)
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Bolt, contentDescription = null, tint = NeonCyanBright, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(text = prompt, fontSize = 12.sp, color = TextPrimary)
                            }
                        }
                    }
                }
            }

            // Generated Draft Result (if any)
            if (generatedDraft != null) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.5.dp, Brush.horizontalGradient(listOf(NeonPurple, NeonCyan)), RoundedCornerShape(16.dp))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = generatedDraft.title,
                                    fontWeight = FontWeight.Bold,
                                    color = NeonCyanBright,
                                    fontSize = 14.sp
                                )
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(NeonPurple.copy(alpha = 0.3f))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("AI READY", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = PureWhite)
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = generatedDraft.content,
                                style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 22.sp),
                                color = PureWhite
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                generatedDraft.tags.forEach { tag ->
                                    Text(text = tag, fontSize = 12.sp, color = NeonCyanBright, fontWeight = FontWeight.Bold)
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            Button(
                                onClick = { onApplyToPost(generatedDraft.content, generatedDraft.tags) },
                                colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.PostAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(if (isArabic) "اعتماد ونشر في منشور جديد" else "Use as New Post", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Library of Pre-Generated AI Inspirations
            item {
                Text(
                    text = if (isArabic) "نماذج وإلهام ذكي تم توليدها:" else "AI Knowledge & Inspiration Hub:",
                    fontWeight = FontWeight.Bold,
                    color = PureWhite,
                    fontSize = 13.sp
                )
            }

            items(aiSuggestions, key = { it.id }) { item ->
                Surface(
                    color = DarkSurface,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(14.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(text = item.title, fontWeight = FontWeight.Bold, color = NeonPurpleGlow, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(text = item.content, fontSize = 12.sp, color = PureWhite)
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            item.tags.forEach { tag ->
                                Text(text = tag, fontSize = 11.sp, color = NeonCyanBright)
                            }
                        }
                    }
                }
            }
        }
    }
}

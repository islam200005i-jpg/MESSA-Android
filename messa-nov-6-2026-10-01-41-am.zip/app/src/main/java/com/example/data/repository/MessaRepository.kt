package com.example.data.repository

import com.example.R
import com.example.data.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.UUID

object MessaRepository {

    // Current User
    private val _currentUser = MutableStateFlow(
        User(
            id = "user_me",
            name = "Sarah Al-Najjar",
            username = "sarah_messa",
            bio = "Digital Architect & AI Explorer ⚡ Crafting the future of social connectivity on MESSA.",
            avatarRes = R.drawable.messa_avatar_creator,
            coverRes = R.drawable.messa_banner,
            followersCount = 28400,
            followingCount = 492,
            isVerified = true,
            isFollowing = false,
            isOnline = true,
            badges = listOf("PRO", "VIP", "CREATOR")
        )
    )
    val currentUser: StateFlow<User> = _currentUser.asStateFlow()

    private val _isAuthenticated = MutableStateFlow(true)
    val isAuthenticated: StateFlow<Boolean> = _isAuthenticated.asStateFlow()

    private val _isDemoMode = MutableStateFlow(true)
    val isDemoMode: StateFlow<Boolean> = _isDemoMode.asStateFlow()

    private val _isArabicLanguage = MutableStateFlow(true)
    val isArabicLanguage: StateFlow<Boolean> = _isArabicLanguage.asStateFlow()

    // Stories
    private val _stories = MutableStateFlow(
        listOf(
            Story(
                id = "story_me",
                userId = "user_me",
                userName = "Your Story",
                userUsername = "sarah_messa",
                userAvatarRes = R.drawable.messa_avatar_creator,
                mediaRes = R.drawable.messa_banner,
                caption = "Testing new holographic UI shaders on MESSA 🚀✨",
                timeAgo = "12m",
                isViewed = false,
                viewersCount = 482
            ),
            Story(
                id = "story_1",
                userId = "user_1",
                userName = "CyberLabs",
                userUsername = "cyberlabs_ai",
                userAvatarRes = R.drawable.messa_logo,
                mediaRes = R.drawable.messa_clip_cyber,
                caption = "Neo-Kyoto nocturnal vibe live streaming now! 🏙️",
                timeAgo = "45m",
                isViewed = false,
                viewersCount = 1204
            ),
            Story(
                id = "story_2",
                userId = "user_2",
                userName = "Elena Rostova",
                userUsername = "elena_quantum",
                userAvatarRes = R.drawable.messa_avatar_creator,
                mediaRes = R.drawable.messa_banner,
                caption = "Quantum neural link initialized! Who is joining MESSA VR space?",
                timeAgo = "1h",
                isViewed = false,
                viewersCount = 943
            ),
            Story(
                id = "story_3",
                userId = "user_3",
                userName = "Tariq Mansoor",
                userUsername = "tariq_tech",
                userAvatarRes = R.drawable.messa_logo,
                mediaRes = R.drawable.messa_clip_cyber,
                caption = "Building next-gen decentralized social protocol #MESSA",
                timeAgo = "2h",
                isViewed = true,
                viewersCount = 630
            )
        )
    )
    val stories: StateFlow<List<Story>> = _stories.asStateFlow()

    // Posts
    private val _posts = MutableStateFlow(
        listOf(
            Post(
                id = "post_1",
                userId = "user_1",
                userName = "CyberLabs Official",
                userUsername = "cyberlabs_ai",
                userAvatarRes = R.drawable.messa_logo,
                isVerified = true,
                content = "Welcome to MESSA Global 🌌\nWe are building the world's most fluid, futuristic social playground combining real-time stories, clips, direct hyper-messaging, and AI-assisted creativity. What feature are you most hyped for?",
                mediaRes = R.drawable.messa_banner,
                mediaType = MediaType.IMAGE,
                likesCount = 1420,
                commentsCount = 89,
                sharesCount = 312,
                isLiked = true,
                isSaved = true,
                isFollowing = true,
                timeAgo = "15m",
                tags = listOf("#MESSA", "#FutureSocial", "#GlobalConnect", "#AI"),
                comments = listOf(
                    Comment(
                        id = "c1",
                        postId = "post_1",
                        userId = "user_2",
                        userName = "Elena Rostova",
                        userUsername = "elena_quantum",
                        userAvatarRes = R.drawable.messa_avatar_creator,
                        content = "The neon visual identity is absolutely gorgeous! Best social experience on mobile.",
                        timeAgo = "10m",
                        likesCount = 24
                    ),
                    Comment(
                        id = "c2",
                        postId = "post_1",
                        userId = "user_3",
                        userName = "Tariq Mansoor",
                        userUsername = "tariq_tech",
                        userAvatarRes = R.drawable.messa_logo,
                        content = "MESSA Clips is so responsive and smooth. Love the AI tools integration!",
                        timeAgo = "5m",
                        likesCount = 12
                    )
                )
            ),
            Post(
                id = "post_2",
                userId = "user_2",
                userName = "Elena Rostova",
                userUsername = "elena_quantum",
                userAvatarRes = R.drawable.messa_avatar_creator,
                isVerified = true,
                content = "Midnight in the hyper-connected city. Just launched our collective gallery in the Cyber Art group. Join the stream and let us know your thoughts! 💜⚡",
                mediaRes = R.drawable.messa_clip_cyber,
                mediaType = MediaType.IMAGE,
                likesCount = 892,
                commentsCount = 43,
                sharesCount = 95,
                isLiked = false,
                isSaved = false,
                isFollowing = false,
                timeAgo = "1h",
                tags = listOf("#CyberArt", "#NeoKyoto", "#DigitalCreators", "#MessaVibes"),
                comments = listOf(
                    Comment(
                        id = "c3",
                        postId = "post_2",
                        userId = "user_me",
                        userName = "Sarah Al-Najjar",
                        userUsername = "sarah_messa",
                        userAvatarRes = R.drawable.messa_avatar_creator,
                        content = "Incredible atmosphere! Inspiring work.",
                        timeAgo = "30m",
                        likesCount = 8
                    )
                )
            ),
            Post(
                id = "post_3",
                userId = "user_3",
                userName = "Tariq Mansoor",
                userUsername = "tariq_tech",
                userAvatarRes = R.drawable.messa_logo,
                isVerified = false,
                content = "Excited to announce our open workshop on AI Agents and Decentralized Social Media next Monday inside MESSA Tech Pioneers group. RSVP in the groups tab!",
                mediaRes = null,
                mediaType = MediaType.NONE,
                likesCount = 415,
                commentsCount = 28,
                sharesCount = 67,
                isLiked = false,
                isSaved = false,
                isFollowing = true,
                timeAgo = "3h",
                tags = listOf("#Workshop", "#Devs", "#Web3", "#TechTalk"),
                comments = emptyList()
            )
        )
    )
    val posts: StateFlow<List<Post>> = _posts.asStateFlow()

    // Clips
    private val _clips = MutableStateFlow(
        listOf(
            Clip(
                id = "clip_1",
                userId = "user_1",
                userName = "CyberCity Streams",
                userUsername = "cybercity_live",
                userAvatarRes = R.drawable.messa_logo,
                videoCoverRes = R.drawable.messa_clip_cyber,
                title = "Flying vehicles over Neo-Kyoto skyline at 2 AM 🛸🌃",
                description = "Captured using holographic ultra-zoom drones. Watch till the end! #Cyberpunk #Clips #Neon #CityLife",
                soundTrack = "MESSA Synthwave Odyssey - Vol. 1",
                likesCount = 28400,
                commentsCount = 1340,
                sharesCount = 5620,
                isLiked = false,
                isFollowing = true,
                tags = listOf("#CyberCity", "#MESSAClips", "#Viral", "#NeoTokyo")
            ),
            Clip(
                id = "clip_2",
                userId = "user_2",
                userName = "Elena Rostova",
                userUsername = "elena_quantum",
                userAvatarRes = R.drawable.messa_avatar_creator,
                videoCoverRes = R.drawable.messa_banner,
                title = "Speed designing a 3D hologram avatar in 60 seconds 🎨⚡",
                description = "Workflow breakdown using neural brushes and neon glow filters. Drop a like if you want the brush pack!",
                soundTrack = "Electronic Dreams - Cyberpulse",
                likesCount = 19700,
                commentsCount = 852,
                sharesCount = 2100,
                isLiked = true,
                isFollowing = false,
                tags = listOf("#3DDesign", "#SpeedArt", "#CreativeMESSA", "#Glow")
            )
        )
    )
    val clips: StateFlow<List<Clip>> = _clips.asStateFlow()

    // Conversations & Messages
    private val _conversations = MutableStateFlow(
        listOf(
            Conversation(
                id = "conv_1",
                user = User(
                    id = "user_2",
                    name = "Elena Rostova",
                    username = "elena_quantum",
                    bio = "Visual artist & neon designer",
                    avatarRes = R.drawable.messa_avatar_creator,
                    isVerified = true,
                    isOnline = true
                ),
                lastMessage = Message(
                    id = "m_last_1",
                    senderId = "user_2",
                    text = "Did you check the new MESSA group collaboration request?",
                    time = "14:28",
                    isSentByMe = false,
                    isRead = false
                ),
                unreadCount = 1,
                messages = listOf(
                    Message("m1", "user_2", "Hey Sarah! Loving your recent post on MESSA 🚀", "14:20", false),
                    Message("m2", "user_me", "Thanks Elena! The feedback from our community has been unreal.", "14:22", true),
                    Message("m3", "user_2", "Did you check the new MESSA group collaboration request?", "14:28", false)
                )
            ),
            Conversation(
                id = "conv_2",
                user = User(
                    id = "user_1",
                    name = "CyberLabs Support",
                    username = "cyberlabs_ai",
                    bio = "Official MESSA ecosystem team",
                    avatarRes = R.drawable.messa_logo,
                    isVerified = true,
                    isOnline = true
                ),
                lastMessage = Message(
                    id = "m_last_2",
                    senderId = "user_1",
                    text = "Your creator badge has been upgraded to VIP level! 🌟",
                    time = "Yesterday",
                    isSentByMe = false,
                    isRead = true
                ),
                unreadCount = 0,
                messages = listOf(
                    Message("m4", "user_1", "Welcome to MESSA Global Creator Program!", "Yesterday", false),
                    Message("m5", "user_1", "Your creator badge has been upgraded to VIP level! 🌟", "Yesterday", false)
                )
            ),
            Conversation(
                id = "conv_3",
                user = User(
                    id = "user_3",
                    name = "Tariq Mansoor",
                    username = "tariq_tech",
                    bio = "Full stack architect",
                    avatarRes = R.drawable.messa_logo,
                    isVerified = false,
                    isOnline = false
                ),
                lastMessage = Message(
                    id = "m_last_3",
                    senderId = "user_me",
                    text = "See you at the Tech Pioneers live room!",
                    time = "2d ago",
                    isSentByMe = true,
                    isRead = true
                ),
                unreadCount = 0,
                messages = listOf(
                    Message("m6", "user_3", "Are you speaking at the AI session next week?", "2d ago", false),
                    Message("m7", "user_me", "See you at the Tech Pioneers live room!", "2d ago", true)
                )
            )
        )
    )
    val conversations: StateFlow<List<Conversation>> = _conversations.asStateFlow()

    // Groups
    private val _groups = MutableStateFlow(
        listOf(
            Group(
                id = "group_1",
                name = "Cyber Art & Holographics",
                description = "Global community for 3D creators, digital futurists, and neon aesthetic lovers.",
                category = "Art & Design",
                avatarRes = R.drawable.messa_banner,
                coverRes = R.drawable.messa_clip_cyber,
                membersCount = 18450,
                isPrivate = false,
                isJoined = true,
                rules = listOf(
                    "Be respectful to all members",
                    "Share only high-quality original or credited digital art",
                    "No unauthorized spam or ads"
                )
            ),
            Group(
                id = "group_2",
                name = "MESSA Tech Pioneers",
                description = "Developers, AI researchers, and engineers shaping future social tech.",
                category = "Technology",
                avatarRes = R.drawable.messa_logo,
                coverRes = R.drawable.messa_banner,
                membersCount = 24100,
                isPrivate = false,
                isJoined = true,
                rules = listOf(
                    "Tech discussions and research only",
                    "Share open source resources freely",
                    "Collaborate constructively"
                )
            ),
            Group(
                id = "group_3",
                name = "Future Global Nomads",
                description = "Connecting innovators, entrepreneurs, and explorers worldwide.",
                category = "Lifestyle",
                avatarRes = R.drawable.messa_avatar_creator,
                coverRes = R.drawable.messa_clip_cyber,
                membersCount = 12900,
                isPrivate = true,
                isJoined = false,
                rules = listOf("Verified accounts only", "Safe space for travel advice")
            )
        )
    )
    val groups: StateFlow<List<Group>> = _groups.asStateFlow()

    // Notifications
    private val _notifications = MutableStateFlow(
        listOf(
            NotificationItem(
                id = "notif_1",
                type = NotificationType.LIKE,
                title = "Elena Rostova liked your post",
                message = "\"Testing new holographic UI shaders on MESSA...\"",
                timeAgo = "5m",
                isRead = false,
                userAvatarRes = R.drawable.messa_avatar_creator
            ),
            NotificationItem(
                id = "notif_2",
                type = NotificationType.FOLLOW,
                title = "New follower",
                message = "Tariq Mansoor started following you",
                timeAgo = "1h",
                isRead = false,
                userAvatarRes = R.drawable.messa_logo
            ),
            NotificationItem(
                id = "notif_3",
                type = NotificationType.SYSTEM,
                title = "MESSA VIP Status Unlocked",
                message = "Congratulations! Your account reached 25,000+ interactions.",
                timeAgo = "1d",
                isRead = true,
                userAvatarRes = R.drawable.messa_logo
            )
        )
    )
    val notifications: StateFlow<List<NotificationItem>> = _notifications.asStateFlow()

    // AI Suggestions
    private val _aiSuggestions = MutableStateFlow(
        listOf(
            AISuggestion(
                id = "ai_1",
                title = "Futuristic Tech Vision",
                content = "The future of human connection is not about scrolling, it's about synchronous immersion. Excited for what we are building with the MESSA community! ⚡🌐",
                tags = listOf("#FutureOfSocial", "#MESSA", "#AIConnection", "#NextGen")
            ),
            AISuggestion(
                id = "ai_2",
                title = "Creative Design Spotlight",
                content = "Neon isn't just a color palette—it's the pulse of digital freedom. Here is my latest concept art created live! Let me know your thoughts 👇",
                tags = listOf("#CyberArt", "#NeonGlow", "#DigitalCreators", "#MESSAAI")
            ),
            AISuggestion(
                id = "ai_3",
                title = "Community Discussion",
                content = "Question for all developers and creators on MESSA: What AI tool fundamentally transformed your daily creative flow this month?",
                tags = listOf("#DevChat", "#AIProductivity", "#MESSA")
            )
        )
    )
    val aiSuggestions: StateFlow<List<AISuggestion>> = _aiSuggestions.asStateFlow()

    // Actions
    fun createPost(content: String, tags: List<String>, withMedia: Boolean = true) {
        val user = _currentUser.value
        val newPost = Post(
            id = "post_${UUID.randomUUID()}",
            userId = user.id,
            userName = user.name,
            userUsername = user.username,
            userAvatarRes = user.avatarRes,
            isVerified = user.isVerified,
            content = content,
            mediaRes = if (withMedia) R.drawable.messa_banner else null,
            mediaType = if (withMedia) MediaType.IMAGE else MediaType.NONE,
            likesCount = 1,
            commentsCount = 0,
            sharesCount = 0,
            isLiked = true,
            isSaved = false,
            isFollowing = false,
            timeAgo = "Just now",
            tags = tags,
            comments = emptyList()
        )
        _posts.update { listOf(newPost) + it }
    }

    fun toggleLikePost(postId: String) {
        _posts.update { list ->
            list.map { post ->
                if (post.id == postId) {
                    val newIsLiked = !post.isLiked
                    val newCount = if (newIsLiked) post.likesCount + 1 else (post.likesCount - 1).coerceAtLeast(0)
                    post.copy(isLiked = newIsLiked, likesCount = newCount)
                } else post
            }
        }
    }

    fun toggleSavePost(postId: String) {
        _posts.update { list ->
            list.map { post ->
                if (post.id == postId) post.copy(isSaved = !post.isSaved) else post
            }
        }
    }

    fun addComment(postId: String, text: String) {
        if (text.isBlank()) return
        val user = _currentUser.value
        val newComment = Comment(
            id = "c_${UUID.randomUUID()}",
            postId = postId,
            userId = user.id,
            userName = user.name,
            userUsername = user.username,
            userAvatarRes = user.avatarRes,
            content = text,
            timeAgo = "Just now",
            likesCount = 0
        )
        _posts.update { list ->
            list.map { post ->
                if (post.id == postId) {
                    post.copy(
                        commentsCount = post.commentsCount + 1,
                        comments = post.comments + newComment
                    )
                } else post
            }
        }
    }

    fun deletePost(postId: String) {
        _posts.update { list -> list.filterNot { it.id == postId } }
    }

    fun addStory(caption: String) {
        val user = _currentUser.value
        val newStory = Story(
            id = "story_${UUID.randomUUID()}",
            userId = user.id,
            userName = user.name,
            userUsername = user.username,
            userAvatarRes = user.avatarRes,
            mediaRes = R.drawable.messa_banner,
            caption = caption,
            timeAgo = "Just now",
            isViewed = false,
            viewersCount = 1
        )
        _stories.update { listOf(newStory) + it }
    }

    fun deleteStory(storyId: String) {
        _stories.update { list -> list.filterNot { it.id == storyId } }
    }

    fun markStoryViewed(storyId: String) {
        _stories.update { list ->
            list.map { if (it.id == storyId) it.copy(isViewed = true) else it }
        }
    }

    fun toggleLikeClip(clipId: String) {
        _clips.update { list ->
            list.map { clip ->
                if (clip.id == clipId) {
                    val newIsLiked = !clip.isLiked
                    val newCount = if (newIsLiked) clip.likesCount + 1 else (clip.likesCount - 1).coerceAtLeast(0)
                    clip.copy(isLiked = newIsLiked, likesCount = newCount)
                } else clip
            }
        }
    }

    fun toggleFollowUser(userId: String) {
        _posts.update { list ->
            list.map { post ->
                if (post.userId == userId) post.copy(isFollowing = !post.isFollowing) else post
            }
        }
        _clips.update { list ->
            list.map { clip ->
                if (clip.userId == userId) clip.copy(isFollowing = !clip.isFollowing) else clip
            }
        }
    }

    fun sendMessage(conversationId: String, text: String, isVoice: Boolean = false) {
        if (text.isBlank() && !isVoice) return
        val newMsg = Message(
            id = "msg_${UUID.randomUUID()}",
            senderId = "user_me",
            text = if (isVoice) "Voice Note (0:15)" else text,
            time = "Now",
            isSentByMe = true,
            isRead = true,
            isVoice = isVoice,
            voiceDurationSec = if (isVoice) 15 else 0
        )
        _conversations.update { list ->
            list.map { conv ->
                if (conv.id == conversationId) {
                    conv.copy(
                        lastMessage = newMsg,
                        messages = conv.messages + newMsg
                    )
                } else conv
            }
        }
    }

    fun createGroup(name: String, description: String, category: String, isPrivate: Boolean) {
        val newGroup = Group(
            id = "group_${UUID.randomUUID()}",
            name = name,
            description = description,
            category = category,
            avatarRes = R.drawable.messa_logo,
            coverRes = R.drawable.messa_banner,
            membersCount = 1,
            isPrivate = isPrivate,
            isJoined = true
        )
        _groups.update { listOf(newGroup) + it }
    }

    fun toggleJoinGroup(groupId: String) {
        _groups.update { list ->
            list.map { g ->
                if (g.id == groupId) {
                    val newJoined = !g.isJoined
                    val newCount = if (newJoined) g.membersCount + 1 else (g.membersCount - 1).coerceAtLeast(1)
                    g.copy(isJoined = newJoined, membersCount = newCount)
                } else g
            }
        }
    }

    fun updateProfile(name: String, username: String, bio: String) {
        _currentUser.update {
            it.copy(
                name = name.ifBlank { it.name },
                username = username.ifBlank { it.username },
                bio = bio.ifBlank { it.bio }
            )
        }
    }

    fun toggleLanguage() {
        _isArabicLanguage.update { !it }
    }

    fun login(email: String) {
        val userName = email.substringBefore("@").replace(".", " ").capitalize()
        _currentUser.update {
            it.copy(
                name = userName.ifBlank { "MESSA User" },
                username = email.substringBefore("@")
            )
        }
        _isAuthenticated.value = true
    }

    fun logout() {
        _isAuthenticated.value = false
    }

    fun generateAiAssistedPost(topic: String): AISuggestion {
        val promptClean = topic.trim()
        val content = if (promptClean.isNotBlank()) {
            "Exploring $promptClean with the global MESSA community! Next-level insights, faster connection, and unlimited creativity. What is your take on this? 💡⚡"
        } else {
            "Stepping into the neon frontier with MESSA. Connecting creators worldwide, one spark at a time! 🌌 #MESSA"
        }
        val tags = listOf(
            "#MESSA",
            "#${promptClean.replace(" ", "").take(12).ifEmpty { "AI" }}",
            "#FutureConnected",
            "#CyberCommunity"
        )
        val suggestion = AISuggestion(
            id = UUID.randomUUID().toString(),
            title = if (promptClean.isNotBlank()) "MESSA AI: $promptClean" else "AI Thought",
            content = content,
            tags = tags
        )
        _aiSuggestions.update { listOf(suggestion) + it }
        return suggestion
    }
}

package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// MESSA Official Colors: Neon Purple, Electric Blue, Cyan, Black, White
val NeonPurple = Color(0xFFA855F7)
val NeonPurpleGlow = Color(0xFFC084FC)
val ElectricBlue = Color(0xFF2563EB)
val ElectricBlueLight = Color(0xFF38BDF8)
val NeonCyan = Color(0xFF06B6D4)
val NeonCyanBright = Color(0xFF22D3EE)

val CyberBlack = Color(0xFF0A0B10)
val DarkSurface = Color(0xFF121420)
val DarkSurfaceElevated = Color(0xFF1A1D2E)
val DarkSurfaceBorder = Color(0xFF2E344D)

val PureWhite = Color(0xFFFFFFFF)
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)

val SuccessGreen = Color(0xFF10B981)
val ErrorRed = Color(0xFFEF4444)
val LikeRed = Color(0xFFFF2A6D)
val StoryGradientStart = Color(0xFFA855F7)
val StoryGradientEnd = Color(0xFF06B6D4)

// Signature Gradients
val MessaGradient = Brush.horizontalGradient(
    colors = listOf(NeonPurple, ElectricBlue, NeonCyan)
)

val MessaVerticalGradient = Brush.verticalGradient(
    colors = listOf(NeonPurple, ElectricBlue, CyberBlack)
)

val MessaCardGradient = Brush.linearGradient(
    colors = listOf(Color(0xFF1A1D2E), Color(0xFF121420))
)

val MessaGlowBrush = Brush.radialGradient(
    colors = listOf(NeonPurple.copy(alpha = 0.35f), Color.Transparent)
)

package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.MessaRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

sealed class Screen {
    object Splash : Screen()
    object Auth : Screen()
    object Main : Screen()
    data class StoryViewer(val story: Story) : Screen()
    data class ChatDetail(val conversationId: String) : Screen()
    data class GroupDetail(val groupId: String) : Screen()
    object MessaAi : Screen()
    object Notifications : Screen()
    object CreatePost : Screen()
    object Messages : Screen()
    object Groups : Screen()
    object Settings : Screen()
}

enum class MainTab {
    FEED, EXPLORE, CREATE, CLIPS, PROFILE
}

class MessaViewModel : ViewModel() {

    private val repository = MessaRepository

    val currentUser = repository.currentUser
    val isAuthenticated = repository.isAuthenticated
    val isDemoMode = repository.isDemoMode
    val isArabic = repository.isArabicLanguage

    val stories = repository.stories
    val posts = repository.posts
    val clips = repository.clips
    val conversations = repository.conversations
    val groups = repository.groups
    val notifications = repository.notifications
    val aiSuggestions = repository.aiSuggestions

    private val _currentScreen = MutableStateFlow<Screen>(Screen.Main)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _selectedTab = MutableStateFlow(MainTab.FEED)
    val selectedTab: StateFlow<MainTab> = _selectedTab.asStateFlow()

    // Active comments post id (for bottom sheet or dialog)
    private val _activeCommentPostId = MutableStateFlow<String?>(null)
    val activeCommentPostId: StateFlow<String?> = _activeCommentPostId.asStateFlow()

    // Search & Filter
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // AI Generation State
    private val _isAiGenerating = MutableStateFlow(false)
    val isAiGenerating: StateFlow<Boolean> = _isAiGenerating.asStateFlow()

    private val _aiGeneratedDraft = MutableStateFlow<AISuggestion?>(null)
    val aiGeneratedDraft: StateFlow<AISuggestion?> = _aiGeneratedDraft.asStateFlow()

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
    }

    fun selectTab(tab: MainTab) {
        if (tab == MainTab.CREATE) {
            _currentScreen.value = Screen.CreatePost
        } else {
            _selectedTab.value = tab
            _currentScreen.value = Screen.Main
        }
    }

    fun navigateBack() {
        when (_currentScreen.value) {
            is Screen.ChatDetail -> {
                _currentScreen.value = Screen.Messages
            }
            is Screen.StoryViewer,
            is Screen.GroupDetail,
            is Screen.MessaAi,
            is Screen.Notifications,
            is Screen.CreatePost,
            Screen.Messages,
            Screen.Groups,
            Screen.Settings -> {
                _currentScreen.value = Screen.Main
            }
            Screen.Auth -> {
                // Stay on auth
            }
            else -> {}
        }
    }

    fun openStory(story: Story) {
        repository.markStoryViewed(story.id)
        _currentScreen.value = Screen.StoryViewer(story)
    }

    fun openChat(conversationId: String) {
        _currentScreen.value = Screen.ChatDetail(conversationId)
    }

    fun openGroup(groupId: String) {
        _currentScreen.value = Screen.GroupDetail(groupId)
    }

    fun openComments(postId: String?) {
        _activeCommentPostId.value = postId
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    // Actions
    fun toggleLikePost(postId: String) = repository.toggleLikePost(postId)
    fun toggleSavePost(postId: String) = repository.toggleSavePost(postId)
    fun addComment(postId: String, text: String) = repository.addComment(postId, text)
    fun deletePost(postId: String) = repository.deletePost(postId)

    fun addStory(caption: String) = repository.addStory(caption)
    fun deleteStory(storyId: String) {
        repository.deleteStory(storyId)
        if (_currentScreen.value is Screen.StoryViewer) {
            _currentScreen.value = Screen.Main
        }
    }

    fun toggleLikeClip(clipId: String) = repository.toggleLikeClip(clipId)
    fun toggleFollowUser(userId: String) = repository.toggleFollowUser(userId)

    fun sendMessage(conversationId: String, text: String, isVoice: Boolean = false) =
        repository.sendMessage(conversationId, text, isVoice)

    fun createPost(content: String, tags: List<String>, withMedia: Boolean) {
        repository.createPost(content, tags, withMedia)
        _currentScreen.value = Screen.Main
        _selectedTab.value = MainTab.FEED
    }

    fun toggleJoinGroup(groupId: String) = repository.toggleJoinGroup(groupId)
    fun createGroup(name: String, desc: String, category: String, isPrivate: Boolean) =
        repository.createGroup(name, desc, category, isPrivate)

    fun updateProfile(name: String, username: String, bio: String) =
        repository.updateProfile(name, username, bio)

    fun toggleLanguage() = repository.toggleLanguage()

    fun login(email: String) {
        repository.login(email)
        _currentScreen.value = Screen.Main
    }

    fun logout() {
        repository.logout()
        _currentScreen.value = Screen.Auth
    }

    fun askAiAssistant(topic: String) {
        viewModelScope.launch {
            _isAiGenerating.value = true
            delay(1200) // Realistic AI synthesis delay
            val suggestion = repository.generateAiAssistedPost(topic)
            _aiGeneratedDraft.value = suggestion
            _isAiGenerating.value = false
        }
    }

    fun clearAiDraft() {
        _aiGeneratedDraft.value = null
    }
}

package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.NeonGradientButton
import com.example.ui.theme.*

@Composable
fun AuthScreen(
    onLoginSuccess: (String) -> Unit,
    isArabic: Boolean = false,
    onLangToggle: () -> Unit
) {
    var isSignUp by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("sarah@messa.social") }
    var password by remember { mutableStateOf("••••••••") }
    var username by remember { mutableStateOf("sarah_messa") }
    var fullName by remember { mutableStateOf("Sarah Al-Najjar") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBlack)
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("auth_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Language Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(
                    onClick = onLangToggle,
                    modifier = Modifier.testTag("auth_lang_toggle")
                ) {
                    Text(
                        text = if (isArabic) "English" else "العربية",
                        color = NeonCyanBright,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Official MESSA Logo
            Box(
                modifier = Modifier
                    .size(90.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .border(2.dp, Brush.sweepGradient(listOf(NeonPurple, ElectricBlue, NeonCyan, NeonPurple)), RoundedCornerShape(24.dp))
                    .padding(2.5.dp)
                    .clip(RoundedCornerShape(22.dp))
            ) {
                Image(
                    painter = painterResource(id = R.drawable.messa_logo),
                    contentDescription = "MESSA Official Logo",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "MESSA",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.sp
                ),
                color = PureWhite
            )

            Text(
                text = if (isArabic) "شبكة التواصل الاجتماعي العالمية" else "Global Social Network",
                style = MaterialTheme.typography.bodySmall,
                color = NeonCyanBright,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(28.dp))

            // Switcher Tabs
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(DarkSurfaceElevated)
                    .padding(4.dp)
            ) {
                TabButton(
                    title = if (isArabic) "تسجيل الدخول" else "Sign In",
                    selected = !isSignUp,
                    onClick = { isSignUp = false },
                    modifier = Modifier.weight(1f)
                )
                TabButton(
                    title = if (isArabic) "إنشاء حساب" else "Sign Up",
                    selected = isSignUp,
                    onClick = { isSignUp = true },
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Fields
            if (isSignUp) {
                OutlinedTextField(
                    value = fullName,
                    onValueChange = { fullName = it },
                    label = { Text(if (isArabic) "الاسم الكامل" else "Full Name") },
                    leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null, tint = NeonPurple) },
                    modifier = Modifier.fillMaxWidth().testTag("auth_name_field"),
                    colors = authTextFieldColors(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = { Text(if (isArabic) "اسم المستخدم" else "Username") },
                    leadingIcon = { Icon(Icons.Default.AlternateEmail, contentDescription = null, tint = NeonCyanBright) },
                    modifier = Modifier.fillMaxWidth().testTag("auth_username_field"),
                    colors = authTextFieldColors(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(12.dp))
            }

            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text(if (isArabic) "البريد الإلكتروني" else "Email Address") },
                leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = NeonCyanBright) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                modifier = Modifier.fillMaxWidth().testTag("auth_email_field"),
                colors = authTextFieldColors(),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text(if (isArabic) "كلمة المرور" else "Password") },
                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = NeonPurple) },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth().testTag("auth_password_field"),
                colors = authTextFieldColors(),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Forgot password
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                Text(
                    text = if (isArabic) "نسيت كلمة المرور؟" else "Forgot password?",
                    fontSize = 12.sp,
                    color = TextSecondary,
                    modifier = Modifier.clickable { /* recovery dialog */ }
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Primary Action Button
            NeonGradientButton(
                text = if (isSignUp) (if (isArabic) "إنشاء حساب الآن" else "Create Account") else (if (isArabic) "دخول إلى MESSA" else "Enter MESSA"),
                onClick = { onLoginSuccess(email) },
                modifier = Modifier.fillMaxWidth(),
                testTag = "auth_submit_button"
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Instant Demo Access Button
            OutlinedButton(
                onClick = { onLoginSuccess("guest_explorer@messa.social") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("auth_guest_button"),
                shape = RoundedCornerShape(12.dp),
                border = ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.horizontalGradient(listOf(NeonPurple, NeonCyan)))
            ) {
                Icon(
                    imageVector = Icons.Default.Bolt,
                    contentDescription = null,
                    tint = NeonCyanBright,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isArabic) "دخول سريع كزائر" else "Quick Guest Access",
                    color = PureWhite,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = if (isArabic) "ألوان MESSA الرسمية: Neon Purple • Electric Blue • Cyan • Black • White" else "Official MESSA Palette: Neon Purple • Electric Blue • Cyan • Black",
                fontSize = 11.sp,
                color = TextTertiary,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun TabButton(
    title: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(9.dp))
            .then(if (selected) Modifier.background(MessaGradient) else Modifier)
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = title,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            color = if (selected) PureWhite else TextSecondary,
            fontSize = 13.sp
        )
    }
}

@Composable
private fun authTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = NeonCyanBright,
    unfocusedBorderColor = DarkSurfaceBorder,
    focusedLabelColor = NeonCyanBright,
    unfocusedLabelColor = TextSecondary,
    focusedTextColor = PureWhite,
    unfocusedTextColor = PureWhite,
    cursorColor = NeonCyanBright,
    focusedContainerColor = DarkSurface,
    unfocusedContainerColor = DarkSurface
)

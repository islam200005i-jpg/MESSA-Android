package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Post
import com.example.data.model.User
import com.example.ui.components.NeonGradientButton
import com.example.ui.theme.*

@Composable
fun ProfileScreen(
    user: User,
    posts: List<Post>,
    isArabic: Boolean = false,
    onUpdateProfile: (String, String, String) -> Unit,
    onSettingsClick: () -> Unit,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedProfileTab by remember { mutableIntStateOf(0) }
    var showEditDialog by remember { mutableStateOf(false) }

    var editName by remember { mutableStateOf(user.name) }
    var editUsername by remember { mutableStateOf(user.username) }
    var editBio by remember { mutableStateOf(user.bio) }

    val myPosts = posts.filter { it.userId == user.id }
    val savedPosts = posts.filter { it.isSaved }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBlack)
            .testTag("profile_screen"),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        // Cover Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp)
            ) {
                Image(
                    painter = painterResource(id = user.coverRes ?: R.drawable.messa_banner),
                    contentDescription = "Cover Image",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(CyberBlack.copy(alpha = 0.2f), CyberBlack.copy(alpha = 0.9f))
                            )
                        )
                )

                // Settings icon in Top-Right Corner with MESSA neon styling
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = 12.dp, end = 14.dp)
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(CyberBlack.copy(alpha = 0.75f))
                        .border(
                            1.5.dp,
                            Brush.sweepGradient(listOf(NeonPurple, ElectricBlue, NeonCyan, NeonPurple)),
                            CircleShape
                        )
                        .clickable(onClick = onSettingsClick)
                        .testTag("profile_settings_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Settings,
                        contentDescription = "Settings",
                        tint = NeonCyanBright,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }

        // Profile Avatar & Badges & Action Buttons
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    // Avatar overlapping cover
                    Box(
                        modifier = Modifier
                            .offset(y = (-40).dp)
                            .size(90.dp)
                            .clip(CircleShape)
                            .border(2.5.dp, Brush.sweepGradient(listOf(NeonPurple, ElectricBlue, NeonCyan, NeonPurple)), CircleShape)
                            .padding(3.dp)
                            .clip(CircleShape)
                    ) {
                        Image(
                            painter = painterResource(id = user.avatarRes ?: R.drawable.messa_avatar_creator),
                            contentDescription = user.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    // Action Buttons Row
                    Row(
                        modifier = Modifier.padding(bottom = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showEditDialog = true },
                            shape = RoundedCornerShape(12.dp),
                            border = ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.horizontalGradient(listOf(NeonPurple, NeonCyan))),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("edit_profile_button")
                        ) {
                            Text(if (isArabic) "تعديل الملف" else "Edit Profile", fontSize = 12.sp, color = PureWhite, fontWeight = FontWeight.Bold)
                        }

                        IconButton(
                            onClick = onSettingsClick,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(DarkSurfaceElevated)
                                .border(1.dp, NeonPurple.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                                .testTag("profile_action_settings_button")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Settings,
                                contentDescription = "Settings",
                                tint = NeonCyanBright,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        IconButton(
                            onClick = onLogout,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(DarkSurfaceElevated)
                                .testTag("logout_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = "Logout", tint = ErrorRed, modifier = Modifier.size(18.dp))
                        }
                    }
                }

                // Name & Verified Badge
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.offset(y = (-24).dp)
                ) {
                    Text(
                        text = user.name,
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black),
                        color = PureWhite
                    )
                    if (user.isVerified) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Verified Creator",
                            tint = NeonCyanBright,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(NeonPurple.copy(alpha = 0.2f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text("VIP CREATOR", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = NeonCyanBright)
                    }
                }

                Text(
                    text = "@${user.username}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    modifier = Modifier.offset(y = (-24).dp)
                )

                Spacer(modifier = Modifier.height(2.dp))

                // Bio
                Text(
                    text = user.bio,
                    style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 22.sp),
                    color = PureWhite,
                    modifier = Modifier.offset(y = (-20).dp)
                )

                // Website Link
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.offset(y = (-16).dp)
                ) {
                    Icon(Icons.Default.Link, contentDescription = null, tint = NeonCyanBright, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = user.website, fontSize = 12.sp, color = NeonCyanBright, fontWeight = FontWeight.SemiBold)
                }

                // Stats Row: Followers, Following, Posts
                Surface(
                    color = DarkSurface,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .offset(y = (-10).dp)
                        .fillMaxWidth()
                        .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(14.dp))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        StatItem(count = "${posts.size}", label = if (isArabic) "منشورات" else "Posts")
                        Divider(modifier = Modifier.height(24.dp).width(0.8.dp), color = DarkSurfaceBorder)
                        StatItem(count = "${user.followersCount}", label = if (isArabic) "متابعون" else "Followers")
                        Divider(modifier = Modifier.height(24.dp).width(0.8.dp), color = DarkSurfaceBorder)
                        StatItem(count = "${user.followingCount}", label = if (isArabic) "يتابع" else "Following")
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Profile Tabs: Posts, Clips, Saved
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(DarkSurfaceElevated)
                        .padding(4.dp)
                ) {
                    ProfileTabItem(
                        title = if (isArabic) "المنشورات" else "Posts",
                        icon = Icons.Default.GridOn,
                        selected = selectedProfileTab == 0,
                        onClick = { selectedProfileTab = 0 },
                        modifier = Modifier.weight(1f)
                    )
                    ProfileTabItem(
                        title = if (isArabic) "المحفوظات" else "Saved",
                        icon = Icons.Default.BookmarkBorder,
                        selected = selectedProfileTab == 1,
                        onClick = { selectedProfileTab = 1 },
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))
            }
        }

        // Tab Content
        val displayedPosts = if (selectedProfileTab == 0) myPosts else savedPosts

        if (displayedPosts.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.PostAdd, contentDescription = null, tint = TextTertiary, modifier = Modifier.size(40.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (isArabic) "لا توجد منشورات في هذا القسم بعد" else "No posts yet in this tab",
                            color = TextSecondary,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        } else {
            items(displayedPosts, key = { it.id }) { post ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                        .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(14.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(text = post.content, color = PureWhite, fontSize = 13.sp, maxLines = 3)
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "❤️ ${post.likesCount} • 💬 ${post.commentsCount}", fontSize = 11.sp, color = TextTertiary)
                            Text(text = post.timeAgo, fontSize = 11.sp, color = TextTertiary)
                        }
                    }
                }
            }
        }
    }

    // Edit Profile Dialog
    if (showEditDialog) {
        AlertDialog(
            onDismissRequest = { showEditDialog = false },
            title = {
                Text(if (isArabic) "تعديل الملف الشخصي" else "Edit Profile", color = PureWhite, fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = editName,
                        onValueChange = { editName = it },
                        label = { Text(if (isArabic) "الاسم" else "Name") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyanBright,
                            unfocusedBorderColor = DarkSurfaceBorder,
                            focusedTextColor = PureWhite,
                            unfocusedTextColor = PureWhite
                        ),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = editUsername,
                        onValueChange = { editUsername = it },
                        label = { Text(if (isArabic) "اسم المستخدم" else "Username") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyanBright,
                            unfocusedBorderColor = DarkSurfaceBorder,
                            focusedTextColor = PureWhite,
                            unfocusedTextColor = PureWhite
                        ),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = editBio,
                        onValueChange = { editBio = it },
                        label = { Text(if (isArabic) "النبذة التعريفية" else "Bio") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyanBright,
                            unfocusedBorderColor = DarkSurfaceBorder,
                            focusedTextColor = PureWhite,
                            unfocusedTextColor = PureWhite
                        )
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onUpdateProfile(editName, editUsername, editBio)
                        showEditDialog = false
                    }
                ) {
                    Text(if (isArabic) "حفظ التغييرات" else "Save Changes", color = NeonCyanBright, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditDialog = false }) {
                    Text(if (isArabic) "إلغاء" else "Cancel", color = TextSecondary)
                }
            },
            containerColor = DarkSurfaceElevated
        )
    }
}

@Composable
private fun StatItem(count: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = count, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = PureWhite)
        Text(text = label, fontSize = 11.sp, color = TextSecondary)
    }
}

@Composable
private fun ProfileTabItem(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .then(if (selected) Modifier.background(MessaGradient) else Modifier)
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = icon, contentDescription = null, tint = if (selected) PureWhite else TextSecondary, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = title, fontSize = 12.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, color = if (selected) PureWhite else TextSecondary)
        }
    }
}

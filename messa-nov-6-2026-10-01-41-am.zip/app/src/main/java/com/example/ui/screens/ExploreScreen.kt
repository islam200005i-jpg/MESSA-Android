package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Group
import com.example.data.model.Post
import com.example.data.model.User
import com.example.ui.theme.*

@Composable
fun ExploreScreen(
    posts: List<Post>,
    groups: List<Group>,
    isArabic: Boolean = false,
    onOpenGroup: (String) -> Unit,
    onFollowUser: (String) -> Unit,
    onOpenPost: (Post) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }

    val categories = listOf("All", "Tech", "Cyber Art", "Clips", "Groups", "Creators")
    val trendingHashtags = listOf(
        "#MESSA" to "142K Posts",
        "#GlobalConnect" to "98K Posts",
        "#AIRevolution" to "65K Posts",
        "#NeoTokyoArt" to "41K Posts",
        "#FuturisticSocial" to "32K Posts"
    )

    val suggestedCreators = listOf(
        User("u_alex", "Alex Mercer", "alex_m", "Neural audio producer & cyber visualist", R.drawable.messa_avatar_creator, isVerified = true),
        User("u_tariq", "Tariq Mansoor", "tariq_tech", "Building next-gen decentralized social protocol", R.drawable.messa_logo, isVerified = false),
        User("u_elena", "Elena Rostova", "elena_quantum", "3D Hologram sculptor & AR developer", R.drawable.messa_avatar_creator, isVerified = true)
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBlack)
            .testTag("explore_screen"),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        // Search bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = {
                    Text(
                        text = if (isArabic) "استكشف الأشخاص، المنشورات، المجموعات والوسوم..." else "Search people, posts, groups & hashtags...",
                        fontSize = 13.sp,
                        color = TextSecondary
                    )
                },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = NeonCyanBright) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp)
                    .testTag("explore_search_bar"),
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonCyanBright,
                    unfocusedBorderColor = DarkSurfaceBorder,
                    focusedTextColor = PureWhite,
                    unfocusedTextColor = PureWhite,
                    focusedContainerColor = DarkSurface,
                    unfocusedContainerColor = DarkSurface
                ),
                singleLine = true
            )
        }

        // Category Filter Chips
        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(vertical = 4.dp)
            ) {
                items(categories) { cat ->
                    val isSelected = selectedCategory == cat
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat, fontSize = 12.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NeonPurple.copy(alpha = 0.25f),
                            selectedLabelColor = NeonCyanBright,
                            labelColor = TextSecondary,
                            containerColor = DarkSurfaceElevated
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = if (isSelected) NeonCyanBright else DarkSurfaceBorder
                        )
                    )
                }
            }
        }

        // Trending Hashtags
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Text(
                    text = if (isArabic) "الوسوم الأكثر تداولاً عالمياً 🔥" else "Trending Worldwide 🔥",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = PureWhite
                )
                Spacer(modifier = Modifier.height(10.dp))

                Surface(
                    color = DarkSurface,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        trendingHashtags.forEachIndexed { index, (tag, count) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = tag, fontWeight = FontWeight.Bold, color = NeonCyanBright, fontSize = 13.sp)
                                    Text(text = count, fontSize = 11.sp, color = TextTertiary)
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(DarkSurfaceElevated)
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(text = "#${index + 1}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = NeonPurpleGlow)
                                }
                            }
                            if (index < trendingHashtags.size - 1) {
                                Divider(color = DarkSurfaceBorder.copy(alpha = 0.4f), thickness = 0.6.dp)
                            }
                        }
                    }
                }
            }
        }

        // Suggested Creators to Follow
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp)
            ) {
                Text(
                    text = if (isArabic) "صناع محتوى مقترحون لمتابعتهم ✨" else "Suggested Creators to Follow ✨",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = PureWhite,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp)
                )

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.padding(vertical = 8.dp)
                ) {
                    items(suggestedCreators) { creator ->
                        Surface(
                            color = DarkSurface,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .width(150.dp)
                                .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(16.dp))
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(54.dp)
                                        .clip(CircleShape)
                                        .border(1.5.dp, Brush.horizontalGradient(listOf(NeonPurple, NeonCyan)), CircleShape)
                                ) {
                                    Image(
                                        painter = painterResource(id = creator.avatarRes ?: R.drawable.messa_logo),
                                        contentDescription = creator.name,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Text(
                                    text = creator.name,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = PureWhite,
                                    maxLines = 1
                                )
                                Text(
                                    text = "@${creator.username}",
                                    fontSize = 10.sp,
                                    color = TextSecondary,
                                    maxLines = 1
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                Button(
                                    onClick = { onFollowUser(creator.id) },
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                                    modifier = Modifier.height(30.dp)
                                ) {
                                    Text(if (isArabic) "متابعة" else "Follow", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Explore Visual Grid / Gallery
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Text(
                    text = if (isArabic) "اكتشف الإبداع في شبكة MESSA 🌌" else "Discover Visual Highlights 🌌",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = PureWhite
                )
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(180.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .border(1.dp, NeonPurple.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.messa_banner),
                            contentDescription = "Visual Highlight 1",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(8.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(CyberBlack.copy(alpha = 0.7f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("#CyberArt", fontSize = 10.sp, color = NeonCyanBright, fontWeight = FontWeight.Bold)
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(180.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .border(1.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.messa_clip_cyber),
                            contentDescription = "Visual Highlight 2",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(8.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(CyberBlack.copy(alpha = 0.7f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("Clips ⚡", fontSize = 10.sp, color = PureWhite, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

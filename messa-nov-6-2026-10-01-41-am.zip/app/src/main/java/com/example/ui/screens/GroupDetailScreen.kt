package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Group
import com.example.data.model.User
import com.example.ui.theme.*

@Composable
fun GroupDetailScreen(
    group: Group?,
    currentUser: User,
    isArabic: Boolean = false,
    onBack: () -> Unit,
    onToggleJoin: (String) -> Unit
) {
    BackHandler { onBack() }

    if (group == null) {
        Box(modifier = Modifier.fillMaxSize().background(CyberBlack), contentAlignment = Alignment.Center) {
            Text(if (isArabic) "المجموعة غير موجودة" else "Group not found", color = TextSecondary)
        }
        return
    }

    var groupPostText by remember { mutableStateOf("") }
    var postsInGroup by remember {
        mutableStateOf(
            listOf(
                "Welcome to ${group.name}! Share your questions, showcase your latest works, and connect with fellow pioneers 🚀",
                "New community guidelines have been updated. Remember to keep discussions respectful and insightful."
            )
        )
    }

    Scaffold(
        topBar = {
            Surface(color = CyberBlack, modifier = Modifier.statusBarsPadding()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("group_detail_back")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = PureWhite)
                    }
                    Text(
                        text = group.name,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = PureWhite,
                        maxLines = 1,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        },
        containerColor = CyberBlack
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .testTag("group_detail_content")
        ) {
            // Header Hero Banner
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                ) {
                    Image(
                        painter = painterResource(id = group.coverRes ?: R.drawable.messa_banner),
                        contentDescription = "Cover",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(CyberBlack.copy(alpha = 0.3f), CyberBlack.copy(alpha = 0.9f))
                                )
                            )
                    )
                }
            }

            // Group Info Block
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = group.name,
                                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                                color = PureWhite
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "${group.membersCount} members • ${group.category} • ${if (group.isPrivate) "Private" else "Public"}",
                                fontSize = 12.sp,
                                color = NeonCyanBright
                            )
                        }

                        Button(
                            onClick = { onToggleJoin(group.id) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (group.isJoined) DarkSurfaceElevated else NeonPurple
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = if (group.isJoined) (if (isArabic) "عضو ✓" else "Joined ✓") else (if (isArabic) "انضمام" else "Join"),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = group.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Rules Card
                    Surface(
                        color = DarkSurface,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(12.dp))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Security, contentDescription = null, tint = NeonPurpleGlow, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isArabic) "قواعد المجتمع والإشراف" else "Group Rules & Moderation",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = PureWhite
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            group.rules.forEach { rule ->
                                Text(text = "• $rule", fontSize = 11.sp, color = TextSecondary)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Post inside group bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = groupPostText,
                            onValueChange = { groupPostText = it },
                            placeholder = { Text(if (isArabic) "اكتب في هذه المجموعة..." else "Post in this group...", fontSize = 12.sp, color = TextSecondary) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(20.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonCyanBright,
                                unfocusedBorderColor = DarkSurfaceBorder,
                                focusedTextColor = PureWhite,
                                unfocusedTextColor = PureWhite,
                                focusedContainerColor = DarkSurface,
                                unfocusedContainerColor = DarkSurface
                            ),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(
                            onClick = {
                                if (groupPostText.isNotBlank()) {
                                    postsInGroup = listOf(groupPostText) + postsInGroup
                                    groupPostText = ""
                                }
                            },
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(MessaGradient)
                        ) {
                            Icon(Icons.Default.Send, contentDescription = "Send", tint = PureWhite, modifier = Modifier.size(18.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = if (isArabic) "منشورات ونقاشات المجموعة" else "Discussions Feed",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = PureWhite
                    )
                }
            }

            // Group Posts
            items(postsInGroup) { text ->
                Surface(
                    color = DarkSurface,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(14.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .border(1.dp, NeonPurple, CircleShape)
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.messa_logo),
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Group Moderator", fontWeight = FontWeight.Bold, color = PureWhite, fontSize = 12.sp)
                                Text("Pinned • Just now", fontSize = 10.sp, color = TextTertiary)
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = text, style = MaterialTheme.typography.bodyMedium, color = PureWhite)
                    }
                }
            }
        }
    }
}

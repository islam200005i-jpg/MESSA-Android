package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.User
import com.example.ui.components.NeonGradientButton
import com.example.ui.theme.*

@Composable
fun CreatePostScreen(
    currentUser: User,
    isArabic: Boolean = false,
    onBack: () -> Unit,
    onPublish: (String, List<String>, Boolean) -> Unit,
    onAskAi: (String) -> Unit
) {
    BackHandler { onBack() }

    var contentText by remember { mutableStateOf("") }
    var withMedia by remember { mutableStateOf(true) }
    var selectedTags by remember { mutableStateOf(listOf("#MESSA", "#GlobalConnect")) }
    var customTag by remember { mutableStateOf("") }
    var showAiAssistDialog by remember { mutableStateOf(false) }
    var aiTopic by remember { mutableStateOf("") }

    val trendingTags = listOf("#FutureTech", "#AIRevolution", "#CyberArt", "#NeonVibes", "#GlobalConnect")

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBlack)
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("create_post_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("create_post_back")) {
                        Icon(Icons.Default.Close, contentDescription = "Cancel", tint = PureWhite)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isArabic) "إنشاء منشور جديد" else "Create Post",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = PureWhite
                    )
                }

                // AI Assist Action Button
                FilledTonalButton(
                    onClick = { showAiAssistDialog = true },
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = NeonPurple.copy(alpha = 0.2f),
                        contentColor = NeonCyanBright
                    ),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("create_post_ai_assist_button")
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "MESSA AI", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // User Info Row
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .border(1.dp, NeonCyanBright, CircleShape)
                ) {
                    Image(
                        painter = painterResource(id = currentUser.avatarRes ?: R.drawable.messa_logo),
                        contentDescription = currentUser.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = currentUser.name,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = PureWhite
                    )
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(DarkSurfaceElevated)
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Icon(Icons.Default.Public, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isArabic) "عام • الجميع" else "Public • Global",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Main Content Input
            OutlinedTextField(
                value = contentText,
                onValueChange = { contentText = it },
                placeholder = {
                    Text(
                        text = if (isArabic) "ماذا تريد أن تشارك مع شبكة MESSA اليوم؟ شارك أفكارك، مشاريعك أو فنك..." else "What would you like to share on MESSA? Ideas, art, tech updates...",
                        color = TextSecondary,
                        fontSize = 14.sp
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 160.dp)
                    .testTag("post_content_input"),
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonCyanBright,
                    unfocusedBorderColor = DarkSurfaceBorder,
                    focusedTextColor = PureWhite,
                    unfocusedTextColor = PureWhite,
                    focusedContainerColor = DarkSurface,
                    unfocusedContainerColor = DarkSurface
                )
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Media attachment toggle & preview
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(DarkSurface)
                    .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(12.dp))
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PhotoLibrary, contentDescription = null, tint = NeonCyanBright)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = if (isArabic) "إرفاق صورة بدقة فائقة" else "Attach High-Res Media",
                        color = PureWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
                Switch(
                    checked = withMedia,
                    onCheckedChange = { withMedia = it },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = PureWhite,
                        checkedTrackColor = NeonPurple,
                        uncheckedTrackColor = DarkSurfaceElevated
                    )
                )
            }

            if (withMedia) {
                Spacer(modifier = Modifier.height(12.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .border(1.dp, NeonPurple.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.messa_banner),
                        contentDescription = "Attachment preview",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp)
                            .clip(CircleShape)
                            .background(CyberBlack.copy(alpha = 0.7f))
                            .clickable { withMedia = false }
                            .padding(6.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Remove", tint = PureWhite, modifier = Modifier.size(16.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Hashtags selector
            Text(
                text = if (isArabic) "الوسوم والهاشتاجات المقترحة:" else "Suggested Tags:",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                color = PureWhite
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                trendingTags.take(3).forEach { tag ->
                    val isSelected = selectedTags.contains(tag)
                    FilterChip(
                        selected = isSelected,
                        onClick = {
                            selectedTags = if (isSelected) selectedTags - tag else selectedTags + tag
                        },
                        label = { Text(tag, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NeonPurple.copy(alpha = 0.3f),
                            selectedLabelColor = NeonCyanBright,
                            labelColor = TextSecondary,
                            containerColor = DarkSurfaceElevated
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = if (isSelected) NeonCyanBright else DarkSurfaceBorder
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Publish Button
            NeonGradientButton(
                text = if (isArabic) "نشر على شبكة MESSA" else "Publish to MESSA Network",
                icon = Icons.Default.RocketLaunch,
                onClick = {
                    if (contentText.isNotBlank()) {
                        onPublish(contentText, selectedTags, withMedia)
                    }
                },
                enabled = contentText.isNotBlank(),
                modifier = Modifier.fillMaxWidth(),
                testTag = "publish_post_button"
            )
        }

        // AI Assist Dialog
        if (showAiAssistDialog) {
            AlertDialog(
                onDismissRequest = { showAiAssistDialog = false },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = NeonPurpleGlow)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (isArabic) "مساعد MESSA AI الذكي" else "MESSA AI Post Helper", color = PureWhite)
                    }
                },
                text = {
                    Column {
                        Text(
                            text = if (isArabic) "اكتب فكرة عامة وسيقوم الذكاء الاصطناعي بصياغة المنشور وتوليد الهاشتاجات المناسبة:" else "Enter a topic and MESSA AI will draft a compelling post with hashtags:",
                            fontSize = 13.sp,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedTextField(
                            value = aiTopic,
                            onValueChange = { aiTopic = it },
                            placeholder = { Text(if (isArabic) "مثال: إطلاق مشروع ذكاء اصطناعي..." else "e.g. Hologram design, AI social...") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonCyanBright,
                                unfocusedBorderColor = DarkSurfaceBorder,
                                focusedTextColor = PureWhite,
                                unfocusedTextColor = PureWhite
                            )
                        )
                    }
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            showAiAssistDialog = false
                            contentText = if (aiTopic.isNotBlank()) {
                                "Exploring $aiTopic with the global MESSA community! Next-level insights, faster connection, and unlimited creativity. What is your take on this? 💡⚡"
                            } else {
                                "Stepping into the neon frontier with MESSA. Connecting creators worldwide, one spark at a time! 🌌 #MESSA"
                            }
                            selectedTags = listOf("#MESSA", "#GlobalConnect", "#FutureTech")
                        }
                    ) {
                        Text(if (isArabic) "توليد واقتباس" else "Generate & Use", color = NeonCyanBright, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAiAssistDialog = false }) {
                        Text(if (isArabic) "إلغاء" else "Cancel", color = TextSecondary)
                    }
                },
                containerColor = DarkSurfaceElevated
            )
        }
    }
}

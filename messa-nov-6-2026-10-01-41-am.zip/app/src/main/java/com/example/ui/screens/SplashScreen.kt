package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.*

@Composable
fun SplashScreen(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBlack)
            .testTag("splash_screen"),
        contentAlignment = Alignment.Center
    ) {
        // Background subtle neon glow
        Box(
            modifier = Modifier
                .size(320.dp)
                .scale(pulseScale)
                .clip(CircleShape)
                .background(MessaGlowBrush)
        )

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Official MESSA Logo
            Box(
                modifier = Modifier
                    .size(160.dp)
                    .scale(pulseScale)
                    .clip(RoundedCornerShape(32.dp))
                    .border(2.dp, Brush.sweepGradient(listOf(NeonPurple, ElectricBlue, NeonCyan, NeonPurple)), RoundedCornerShape(32.dp))
                    .padding(3.dp)
                    .clip(RoundedCornerShape(29.dp))
            ) {
                Image(
                    painter = painterResource(id = R.drawable.messa_logo),
                    contentDescription = "MESSA Official Logo",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.height(44.dp))

            // Loading bar
            CircularProgressIndicator(
                modifier = Modifier.size(32.dp),
                color = NeonCyanBright,
                trackColor = DarkSurfaceBorder,
                strokeWidth = 3.dp
            )
        }

        // Footer version
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 24.dp)
        ) {
            Text(
                text = "MESSA Global Network",
                fontSize = 12.sp,
                color = TextTertiary
            )
        }
    }
}

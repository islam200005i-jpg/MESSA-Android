package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Clip
import com.example.ui.theme.*

@Composable
fun ClipsScreen(
    clips: List<Clip>,
    isArabic: Boolean = false,
    onLikeClip: (String) -> Unit,
    onFollowUser: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val pagerState = rememberPagerState(pageCount = { clips.size })

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBlack)
            .testTag("clips_screen")
    ) {
        if (clips.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    text = if (isArabic) "لا توجد فيديوهات clips حالياً" else "No clips available",
                    color = TextSecondary
                )
            }
        } else {
            VerticalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize()
            ) { page ->
                val clip = clips[page]
                ClipPageItem(
                    clip = clip,
                    isArabic = isArabic,
                    onLike = { onLikeClip(clip.id) },
                    onFollow = { onFollowUser(clip.userId) }
                )
            }
        }
    }
}

@Composable
private fun ClipPageItem(
    clip: Clip,
    isArabic: Boolean,
    onLike: () -> Unit,
    onFollow: () -> Unit
) {
    var isPlaying by remember { mutableStateOf(true) }
    var showCommentsDialog by remember { mutableStateOf(false) }

    // Spinning soundtrack disc animation
    val infiniteTransition = rememberInfiniteTransition(label = "disc")
    val discRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .clickable { isPlaying = !isPlaying }
    ) {
        // Fullscreen Visual Feed / Background
        Image(
            painter = painterResource(id = clip.videoCoverRes ?: R.drawable.messa_clip_cyber),
            contentDescription = clip.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // Gradient overlay for readability
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            CyberBlack.copy(alpha = 0.4f),
                            Color.Transparent,
                            CyberBlack.copy(alpha = 0.85f)
                        )
                    )
                )
        )

        // Play / Pause central indicator if paused
        if (!isPlaying) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .align(Alignment.Center)
                    .clip(CircleShape)
                    .background(CyberBlack.copy(alpha = 0.6f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Paused",
                    tint = PureWhite,
                    modifier = Modifier.size(36.dp)
                )
            }
        }

        // Top Header Tag
        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .statusBarsPadding()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(CyberBlack.copy(alpha = 0.6f))
                    .border(1.dp, NeonPurple, RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "MESSA Clips",
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    ),
                    color = NeonCyanBright
                )
            }
        }

        // Right Action Stack
        Column(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 14.dp, bottom = 90.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Creator Avatar with Follow (+) badge
            Box(contentAlignment = Alignment.BottomCenter) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .border(2.dp, Brush.horizontalGradient(listOf(NeonPurple, NeonCyan)), CircleShape)
                ) {
                    Image(
                        painter = painterResource(id = clip.userAvatarRes ?: R.drawable.messa_logo),
                        contentDescription = clip.userName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                if (!clip.isFollowing) {
                    Box(
                        modifier = Modifier
                            .offset(y = 8.dp)
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(MessaGradient)
                            .clickable(onClick = onFollow),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Follow",
                            tint = PureWhite,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Like Action
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                IconButton(
                    onClick = onLike,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(CyberBlack.copy(alpha = 0.5f))
                        .testTag("clip_like_button_${clip.id}")
                ) {
                    Icon(
                        imageVector = if (clip.isLiked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                        contentDescription = "Like Clip",
                        tint = if (clip.isLiked) LikeRed else PureWhite,
                        modifier = Modifier.size(26.dp)
                    )
                }
                Text(
                    text = "${clip.likesCount}",
                    color = PureWhite,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Comment Action
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                IconButton(
                    onClick = { showCommentsDialog = true },
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(CyberBlack.copy(alpha = 0.5f))
                ) {
                    Icon(
                        imageVector = Icons.Filled.Comment,
                        contentDescription = "Comments",
                        tint = PureWhite,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Text(
                    text = "${clip.commentsCount}",
                    color = PureWhite,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Share Action
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                IconButton(
                    onClick = { /* Share */ },
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(CyberBlack.copy(alpha = 0.5f))
                ) {
                    Icon(
                        imageVector = Icons.Filled.Share,
                        contentDescription = "Share",
                        tint = PureWhite,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Text(
                    text = "${clip.sharesCount}",
                    color = PureWhite,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Spinning soundtrack vinyl
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .rotate(if (isPlaying) discRotation else 0f)
                    .clip(CircleShape)
                    .background(Brush.radialGradient(listOf(DarkSurfaceBorder, CyberBlack)))
                    .border(2.dp, NeonPurpleGlow, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.MusicNote,
                    contentDescription = null,
                    tint = NeonCyanBright,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        // Bottom Left Info Bar
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth(0.8f)
                .padding(start = 16.dp, bottom = 90.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "@${clip.userUsername}",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = PureWhite
                )
                Spacer(modifier = Modifier.width(6.dp))
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = NeonCyanBright, modifier = Modifier.size(14.dp))
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = clip.title,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                color = PureWhite,
                maxLines = 2
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = clip.description,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                maxLines = 2
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Audio track ticker
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(CyberBlack.copy(alpha = 0.5f))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Icon(Icons.Default.MusicNote, contentDescription = null, tint = NeonCyanBright, modifier = Modifier.size(12.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = clip.soundTrack,
                    fontSize = 11.sp,
                    color = PureWhite,
                    maxLines = 1
                )
            }
        }

        // Comments Bottom Sheet Dialog
        if (showCommentsDialog) {
            AlertDialog(
                onDismissRequest = { showCommentsDialog = false },
                title = {
                    Text(
                        text = if (isArabic) "تعليقات MESSA Clips" else "Clips Comments",
                        color = PureWhite,
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Column {
                        Text("• CyberFan: Mind-blowing visuals! 🔥", color = PureWhite, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("• NeoArtist: The lighting shaders look unreal 💜", color = PureWhite, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("• TechPioneer: MESSA Global at its best ⚡", color = PureWhite, fontSize = 13.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showCommentsDialog = false }) {
                        Text(if (isArabic) "إغلاق" else "Close", color = NeonCyanBright)
                    }
                },
                containerColor = DarkSurfaceElevated
            )
        }
    }
}

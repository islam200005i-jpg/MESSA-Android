package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.User
import com.example.ui.theme.*

@Composable
fun SettingsScreen(
    user: User,
    isArabic: Boolean = false,
    onBack: () -> Unit,
    onUpdateProfile: (String, String, String) -> Unit,
    onToggleLanguage: () -> Unit,
    onLogout: () -> Unit
) {
    BackHandler { onBack() }

    // Dialog & Toggle states
    var showEditProfileDialog by remember { mutableStateOf(false) }
    var showAccountSecurityDialog by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var showBlockedUsersDialog by remember { mutableStateOf(false) }
    var showHelpDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }
    var showLogoutConfirmDialog by remember { mutableStateOf(false) }

    // Settings preference states
    var pushNotificationsEnabled by remember { mutableStateOf(true) }
    var storyAlertsEnabled by remember { mutableStateOf(true) }
    var isPrivateAccount by remember { mutableStateOf(false) }
    var showOnlineStatus by remember { mutableStateOf(true) }
    var twoFactorAuthEnabled by remember { mutableStateOf(true) }
    var isDarkMode by remember { mutableStateOf(true) }

    // Edit profile field states
    var editName by remember { mutableStateOf(user.name) }
    var editUsername by remember { mutableStateOf(user.username) }
    var editBio by remember { mutableStateOf(user.bio) }

    // Blocked users list state
    var blockedUsers by remember {
        mutableStateOf(
            listOf(
                "SpamBot_99 (@spambot99)",
                "CyberTroll (@troll_ai)",
                "Unknown_User_3 (@unwanted)"
            )
        )
    }

    Scaffold(
        topBar = {
            Surface(
                color = CyberBlack,
                modifier = Modifier.statusBarsPadding()
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier.testTag("settings_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = PureWhite
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isArabic) "الإعدادات" else "Settings",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            ),
                            color = PureWhite
                        )
                    }
                    HorizontalDivider(
                        color = DarkSurfaceBorder.copy(alpha = 0.5f),
                        thickness = 0.8.dp
                    )
                }
            }
        },
        containerColor = CyberBlack
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .testTag("settings_content"),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // User Header Card
            item {
                Surface(
                    color = DarkSurface,
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            1.dp,
                            Brush.horizontalGradient(listOf(NeonPurple.copy(alpha = 0.6f), NeonCyan.copy(alpha = 0.6f))),
                            RoundedCornerShape(18.dp)
                        )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .border(1.5.dp, Brush.horizontalGradient(listOf(NeonPurple, NeonCyan)), CircleShape)
                        ) {
                            Image(
                                painter = painterResource(id = user.avatarRes ?: R.drawable.messa_avatar_creator),
                                contentDescription = user.name,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = user.name,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = PureWhite
                                )
                                if (user.isVerified) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = "Verified",
                                        tint = NeonCyanBright,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                            Text(
                                text = "@${user.username}",
                                fontSize = 12.sp,
                                color = TextSecondary
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(NeonPurple.copy(alpha = 0.2f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "VIP",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = NeonCyanBright
                            )
                        }
                    }
                }
            }

            // Section: Account Management
            item {
                SettingsSectionCard(
                    title = if (isArabic) "الحساب والملف الشخصي" else "Account & Profile"
                ) {
                    // 1. Edit Profile
                    SettingsRowItem(
                        icon = Icons.Outlined.Person,
                        iconTint = NeonPurpleGlow,
                        title = if (isArabic) "تعديل الملف الشخصي" else "Edit Profile",
                        subtitle = if (isArabic) "تغيير الاسم، اسم المستخدم والنبذة" else "Change name, username and bio",
                        onClick = { showEditProfileDialog = true },
                        testTag = "settings_edit_profile"
                    )

                    SettingsDivider()

                    // 2. Account & Security
                    SettingsRowItem(
                        icon = Icons.Outlined.Security,
                        iconTint = NeonCyanBright,
                        title = if (isArabic) "الحساب والأمان" else "Account & Security",
                        subtitle = if (isArabic) "كلمة المرور، المصادقة الثنائية 2FA" else "Password, Two-Factor Authentication",
                        onClick = { showAccountSecurityDialog = true },
                        testTag = "settings_account_security"
                    )

                    SettingsDivider()

                    // 3. Privacy Settings
                    SettingsRowItem(
                        icon = Icons.Outlined.Lock,
                        iconTint = ElectricBlue,
                        title = if (isArabic) "إعدادات الخصوصية" else "Privacy Settings",
                        subtitle = if (isArabic) "حساب خاص، حالة الاتصال والظهور" else "Private account, activity status",
                        onClick = { showPrivacyDialog = true },
                        testTag = "settings_privacy"
                    )
                }
            }

            // Section: Preferences & Experience
            item {
                SettingsSectionCard(
                    title = if (isArabic) "التفضيلات والتجربة" else "Preferences & Experience"
                ) {
                    // 4. Notifications
                    SettingsSwitchRowItem(
                        icon = Icons.Outlined.Notifications,
                        iconTint = NeonCyanBright,
                        title = if (isArabic) "الإشعارات" else "Notifications",
                        subtitle = if (isArabic) "تنبيهات المنشورات والرسائل والقصص" else "Push alerts, messages, and stories",
                        checked = pushNotificationsEnabled,
                        onCheckedChange = { pushNotificationsEnabled = it },
                        testTag = "settings_notifications_switch"
                    )

                    SettingsDivider()

                    // 5. Language
                    SettingsRowItem(
                        icon = Icons.Outlined.Language,
                        iconTint = NeonPurpleGlow,
                        title = if (isArabic) "اللغة" else "Language",
                        subtitle = if (isArabic) "العربية (الحالية) • انقر للتبديل" else "English (Active) • Tap to switch",
                        badge = if (isArabic) "العربية" else "English",
                        onClick = onToggleLanguage,
                        testTag = "settings_language"
                    )

                    SettingsDivider()

                    // 6. Appearance (Dark / Light Mode)
                    SettingsSwitchRowItem(
                        icon = Icons.Outlined.DarkMode,
                        iconTint = ElectricBlue,
                        title = if (isArabic) "المظهر (الوضع الليلي)" else "Appearance (Dark Mode)",
                        subtitle = if (isArabic) "تصميم نيون مستقبلي داكن (MESSA Cyber)" else "Futuristic dark cyber neon aesthetic",
                        checked = isDarkMode,
                        onCheckedChange = { isDarkMode = it },
                        testTag = "settings_appearance_switch"
                    )
                }
            }

            // Section: Community & Security
            item {
                SettingsSectionCard(
                    title = if (isArabic) "المجتمع والأمان" else "Community & Safety"
                ) {
                    // 7. Blocked Users
                    SettingsRowItem(
                        icon = Icons.Outlined.Block,
                        iconTint = ErrorRed,
                        title = if (isArabic) "المستخدمون المحظورون" else "Blocked Users",
                        subtitle = if (isArabic) "${blockedUsers.size} مستخدمين في قائمة الحظر" else "${blockedUsers.size} users blocked",
                        onClick = { showBlockedUsersDialog = true },
                        testTag = "settings_blocked_users"
                    )

                    SettingsDivider()

                    // 8. Help & Support
                    SettingsRowItem(
                        icon = Icons.Outlined.HelpOutline,
                        iconTint = NeonCyanBright,
                        title = if (isArabic) "المساعدة والدعم" else "Help & Support",
                        subtitle = if (isArabic) "الأسئلة الشائعة، الدعم الفني، إبلاغ" else "FAQ, Contact support, Community guidelines",
                        onClick = { showHelpDialog = true },
                        testTag = "settings_help_support"
                    )

                    SettingsDivider()

                    // 9. About MESSA
                    SettingsRowItem(
                        icon = Icons.Outlined.Info,
                        iconTint = NeonPurpleGlow,
                        title = if (isArabic) "حول MESSA" else "About MESSA",
                        subtitle = if (isArabic) "الإصدار 1.0.0 • شروط الخدمة والخصوصية" else "v1.0.0 • Terms, Privacy & Brand",
                        onClick = { showAboutDialog = true },
                        testTag = "settings_about_messa"
                    )
                }
            }

            // Section: Session Actions (10. Log Out)
            item {
                Surface(
                    color = DarkSurface,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, ErrorRed.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showLogoutConfirmDialog = true }
                            .padding(16.dp)
                            .testTag("settings_logout"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(ErrorRed.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Logout,
                                contentDescription = "Log Out",
                                tint = ErrorRed,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isArabic) "تسجيل الخروج" else "Log Out",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = ErrorRed
                            )
                            Text(
                                text = if (isArabic) "الخروج الآمن من حسابك على هذا الجهاز" else "Securely sign out of your account",
                                fontSize = 12.sp,
                                color = TextTertiary
                            )
                        }

                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                            contentDescription = null,
                            tint = ErrorRed.copy(alpha = 0.6f),
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    // 1. Edit Profile Dialog
    if (showEditProfileDialog) {
        AlertDialog(
            onDismissRequest = { showEditProfileDialog = false },
            title = {
                Text(
                    text = if (isArabic) "تعديل الملف الشخصي" else "Edit Profile",
                    color = PureWhite,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = editName,
                        onValueChange = { editName = it },
                        label = { Text(if (isArabic) "الاسم" else "Name") },
                        modifier = Modifier.fillMaxWidth().testTag("edit_name_input"),
                        colors = settingsTextFieldColors(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = editUsername,
                        onValueChange = { editUsername = it },
                        label = { Text(if (isArabic) "اسم المستخدم" else "Username") },
                        modifier = Modifier.fillMaxWidth().testTag("edit_username_input"),
                        colors = settingsTextFieldColors(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = editBio,
                        onValueChange = { editBio = it },
                        label = { Text(if (isArabic) "النبذة التعريفية" else "Bio") },
                        modifier = Modifier.fillMaxWidth().testTag("edit_bio_input"),
                        colors = settingsTextFieldColors()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onUpdateProfile(editName, editUsername, editBio)
                        showEditProfileDialog = false
                    }
                ) {
                    Text(
                        text = if (isArabic) "حفظ التغييرات" else "Save Changes",
                        color = NeonCyanBright,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditProfileDialog = false }) {
                    Text(if (isArabic) "إلغاء" else "Cancel", color = TextSecondary)
                }
            },
            containerColor = DarkSurfaceElevated
        )
    }

    // 2. Account & Security Dialog
    if (showAccountSecurityDialog) {
        AlertDialog(
            onDismissRequest = { showAccountSecurityDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Security, contentDescription = null, tint = NeonCyanBright)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isArabic) "الحساب والأمان" else "Account & Security",
                        color = PureWhite,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = if (isArabic) "البريد الإلكتروني المرتبط:" else "Linked Email:",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                    Text(
                        text = "sarah@messa.social",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = PureWhite
                    )

                    HorizontalDivider(color = DarkSurfaceBorder)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isArabic) "المصادقة الثنائية (2FA)" else "Two-Factor Auth (2FA)",
                                fontWeight = FontWeight.SemiBold,
                                color = PureWhite,
                                fontSize = 13.sp
                            )
                            Text(
                                text = if (isArabic) "حماية حسابك برمز إضافي" else "Extra security on sign-in",
                                fontSize = 11.sp,
                                color = TextTertiary
                            )
                        }
                        Switch(
                            checked = twoFactorAuthEnabled,
                            onCheckedChange = { twoFactorAuthEnabled = it },
                            colors = switchColors()
                        )
                    }

                    HorizontalDivider(color = DarkSurfaceBorder)

                    Button(
                        onClick = { showAccountSecurityDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurface),
                        border = ButtonDefaults.outlinedButtonBorder.copy(
                            brush = Brush.horizontalGradient(listOf(NeonPurple, NeonCyan))
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (isArabic) "تغيير كلمة المرور" else "Change Password",
                            color = PureWhite,
                            fontSize = 12.sp
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAccountSecurityDialog = false }) {
                    Text(if (isArabic) "إغلاق" else "Done", color = NeonCyanBright, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = DarkSurfaceElevated
        )
    }

    // 3. Privacy Settings Dialog
    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Lock, contentDescription = null, tint = ElectricBlue)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isArabic) "إعدادات الخصوصية" else "Privacy Settings",
                        color = PureWhite,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isArabic) "حساب خاص (Private)" else "Private Account",
                                fontWeight = FontWeight.SemiBold,
                                color = PureWhite,
                                fontSize = 13.sp
                            )
                            Text(
                                text = if (isArabic) "يجب قبول المتابعين الجدد يدوياً" else "Only approved users see posts",
                                fontSize = 11.sp,
                                color = TextTertiary
                            )
                        }
                        Switch(
                            checked = isPrivateAccount,
                            onCheckedChange = { isPrivateAccount = it },
                            colors = switchColors()
                        )
                    }

                    HorizontalDivider(color = DarkSurfaceBorder)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isArabic) "حالة النشاط (متصل الآن)" else "Activity Status",
                                fontWeight = FontWeight.SemiBold,
                                color = PureWhite,
                                fontSize = 13.sp
                            )
                            Text(
                                text = if (isArabic) "إظهار النقطة الخضراء عند اتصالك" else "Show green dot when online",
                                fontSize = 11.sp,
                                color = TextTertiary
                            )
                        }
                        Switch(
                            checked = showOnlineStatus,
                            onCheckedChange = { showOnlineStatus = it },
                            colors = switchColors()
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showPrivacyDialog = false }) {
                    Text(if (isArabic) "حفظ وإغلاق" else "Save & Close", color = NeonCyanBright, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = DarkSurfaceElevated
        )
    }

    // 7. Blocked Users Dialog
    if (showBlockedUsersDialog) {
        AlertDialog(
            onDismissRequest = { showBlockedUsersDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Block, contentDescription = null, tint = ErrorRed)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isArabic) "المستخدمون المحظورون" else "Blocked Users",
                        color = PureWhite,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (blockedUsers.isEmpty()) {
                        Text(
                            text = if (isArabic) "قائمة الحظر فارغة" else "No blocked users",
                            fontSize = 13.sp,
                            color = TextSecondary
                        )
                    } else {
                        blockedUsers.forEach { blockedUser ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = blockedUser,
                                    fontSize = 12.sp,
                                    color = PureWhite,
                                    modifier = Modifier.weight(1f)
                                )
                                TextButton(
                                    onClick = {
                                        blockedUsers = blockedUsers.filter { it != blockedUser }
                                    }
                                ) {
                                    Text(
                                        text = if (isArabic) "إلغاء الحظر" else "Unblock",
                                        color = NeonCyanBright,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showBlockedUsersDialog = false }) {
                    Text(if (isArabic) "إغلاق" else "Close", color = PureWhite)
                }
            },
            containerColor = DarkSurfaceElevated
        )
    }

    // 8. Help & Support Dialog
    if (showHelpDialog) {
        AlertDialog(
            onDismissRequest = { showHelpDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.HelpOutline, contentDescription = null, tint = NeonCyanBright)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isArabic) "المساعدة والدعم" else "Help & Support",
                        color = PureWhite,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = if (isArabic)
                            "• مركز المساعدة: إجابات على جميع الأسئلة الشائعة حول MESSA.\n• الإبلاغ عن مشكلة: أرسل تقريراً تقنياً فورياً لفريق الدعم.\n• إرشادات المجتمع: معايير السلامة والتواصل الآمن.\n• تواصل معنا: support@messa.social"
                        else
                            "• Help Center: Answers to common questions about MESSA.\n• Report a Problem: Submit an instant report to our team.\n• Community Guidelines: Safe and respectful interaction.\n• Contact Support: support@messa.social",
                        fontSize = 13.sp,
                        color = TextSecondary,
                        lineHeight = 20.sp
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showHelpDialog = false }) {
                    Text(if (isArabic) "حسناً" else "Got it", color = NeonCyanBright, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = DarkSurfaceElevated
        )
    }

    // 9. About MESSA Dialog
    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(30.dp)
                            .clip(CircleShape)
                            .border(1.dp, NeonPurple, CircleShape)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.messa_logo),
                            contentDescription = "MESSA",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "MESSA Social Network",
                        color = PureWhite,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Version 1.0.0 (Build 2026.11)",
                        fontSize = 12.sp,
                        color = NeonCyanBright,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isArabic)
                            "MESSA هي شبكة التواصل الاجتماعي العالمية المستقبلية التي تجمع بين المنشورات، القصص، الفيديوهات القصيرة، المحادثات الخاصة ومحرك الذكاء الاصطناعي."
                        else
                            "MESSA is the global futuristic social network combining Feed, Stories, Clips, Direct Messaging, and an AI creative engine.",
                        fontSize = 13.sp,
                        color = TextSecondary,
                        lineHeight = 18.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "© 2026 MESSA Global Inc. All rights reserved.",
                        fontSize = 10.sp,
                        color = TextTertiary
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showAboutDialog = false }) {
                    Text(if (isArabic) "إغلاق" else "Close", color = NeonCyanBright, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = DarkSurfaceElevated
        )
    }

    // 10. Logout Confirmation Dialog
    if (showLogoutConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutConfirmDialog = false },
            title = {
                Text(
                    text = if (isArabic) "تأكيد تسجيل الخروج" else "Log Out Confirmation",
                    color = ErrorRed,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = if (isArabic)
                        "هل أنت متأكد من رغبتك في تسجيل الخروج من حسابك على MESSA؟"
                    else
                        "Are you sure you want to log out of your MESSA account?",
                    color = PureWhite,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showLogoutConfirmDialog = false
                        onLogout()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ErrorRed),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = if (isArabic) "تسجيل الخروج" else "Log Out",
                        color = PureWhite,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutConfirmDialog = false }) {
                    Text(if (isArabic) "إلغاء" else "Cancel", color = TextSecondary)
                }
            },
            containerColor = DarkSurfaceElevated
        )
    }
}

@Composable
private fun SettingsSectionCard(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelLarge.copy(
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            ),
            color = NeonCyanBright,
            modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
        )
        Surface(
            color = DarkSurface,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(16.dp))
        ) {
            Column(
                modifier = Modifier.padding(vertical = 4.dp),
                content = content
            )
        }
    }
}

@Composable
private fun SettingsRowItem(
    icon: ImageVector,
    iconTint: Color,
    title: String,
    subtitle: String,
    badge: String? = null,
    onClick: () -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(iconTint.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = iconTint,
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp
                ),
                color = PureWhite
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                color = TextSecondary
            )
        }

        if (badge != null) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(NeonPurple.copy(alpha = 0.25f))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(
                    text = badge,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeonCyanBright
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
        }

        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
            contentDescription = null,
            tint = TextTertiary,
            modifier = Modifier.size(13.dp)
        )
    }
}

@Composable
private fun SettingsSwitchRowItem(
    icon: ImageVector,
    iconTint: Color,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(iconTint.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = iconTint,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp
                    ),
                    color = PureWhite
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                    color = TextSecondary
                )
            }
        }

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = switchColors()
        )
    }
}

@Composable
private fun SettingsDivider() {
    HorizontalDivider(
        color = DarkSurfaceBorder.copy(alpha = 0.5f),
        thickness = 0.6.dp,
        modifier = Modifier.padding(horizontal = 16.dp)
    )
}

@Composable
private fun switchColors() = SwitchDefaults.colors(
    checkedThumbColor = PureWhite,
    checkedTrackColor = NeonPurple,
    uncheckedThumbColor = TextSecondary,
    uncheckedTrackColor = DarkSurfaceElevated,
    uncheckedBorderColor = DarkSurfaceBorder
)

@Composable
private fun settingsTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = NeonCyanBright,
    unfocusedBorderColor = DarkSurfaceBorder,
    focusedLabelColor = NeonCyanBright,
    unfocusedLabelColor = TextSecondary,
    focusedTextColor = PureWhite,
    unfocusedTextColor = PureWhite,
    focusedContainerColor = CyberBlack,
    unfocusedContainerColor = CyberBlack
)

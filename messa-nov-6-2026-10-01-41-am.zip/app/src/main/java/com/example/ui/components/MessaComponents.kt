package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.MainTab
import com.example.ui.theme.*

@Composable
fun MessaTopBar(
    title: String = "MESSA",
    subtitle: String? = null,
    unreadMessages: Int = 1,
    unreadNotifications: Int = 2,
    isArabic: Boolean = false,
    onMessagesClick: () -> Unit,
    onNotificationsClick: () -> Unit,
    onAiClick: () -> Unit,
    onSearchClick: () -> Unit,
    onLangToggle: () -> Unit
) {
    Surface(
        color = CyberBlack.copy(alpha = 0.95f),
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding(),
        tonalElevation = 6.dp
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Brand Left
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.testTag("brand_header")
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .border(1.5.dp, Brush.horizontalGradient(listOf(NeonPurple, NeonCyan)), CircleShape)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.messa_logo),
                            contentDescription = "MESSA Logo",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.2.sp
                                ),
                                color = PureWhite
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(NeonPurple.copy(alpha = 0.25f))
                                    .padding(horizontal = 5.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "GLOBAL",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NeonCyanBright
                                )
                            }
                        }
                        if (subtitle != null) {
                            Text(
                                text = subtitle,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                ),
                                color = TextSecondary
                            )
                        }
                    }
                }

                // Action Icons Right
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Language Switcher
                    IconButton(
                        onClick = onLangToggle,
                        modifier = Modifier.size(36.dp).testTag("lang_toggle_button")
                    ) {
                        Text(
                            text = if (isArabic) "EN" else "عربي",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = NeonCyanBright
                        )
                    }

                    // AI Button with glowing indicator
                    IconButton(
                        onClick = onAiClick,
                        modifier = Modifier
                            .size(38.dp)
                            .testTag("messa_ai_header_button")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "MESSA AI",
                                tint = NeonPurpleGlow,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }

                    // Notifications
                    IconButton(
                        onClick = onNotificationsClick,
                        modifier = Modifier
                            .size(38.dp)
                            .testTag("notifications_header_button")
                    ) {
                        BadgedBox(
                            badge = {
                                if (unreadNotifications > 0) {
                                    Badge(
                                        containerColor = NeonPurple,
                                        contentColor = PureWhite
                                    ) {
                                        Text(unreadNotifications.toString(), fontSize = 10.sp)
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Notifications,
                                contentDescription = "Notifications",
                                tint = PureWhite,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }

                    // Direct Messages
                    IconButton(
                        onClick = onMessagesClick,
                        modifier = Modifier
                            .size(38.dp)
                            .testTag("messages_header_button")
                    ) {
                        BadgedBox(
                            badge = {
                                if (unreadMessages > 0) {
                                    Badge(
                                        containerColor = NeonCyan,
                                        contentColor = CyberBlack
                                    ) {
                                        Text(unreadMessages.toString(), fontSize = 10.sp)
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.ChatBubbleOutline,
                                contentDescription = "Messages",
                                tint = PureWhite,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                }
            }
            Divider(color = DarkSurfaceBorder.copy(alpha = 0.5f), thickness = 0.8.dp)
        }
    }
}

@Composable
fun MessaBottomNav(
    selectedTab: MainTab,
    onTabSelected: (MainTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = CyberBlack.copy(alpha = 0.98f),
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding(),
        tonalElevation = 8.dp
    ) {
        Column {
            Divider(color = DarkSurfaceBorder.copy(alpha = 0.6f), thickness = 0.8.dp)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 1. Home / Feed
                NavItem(
                    label = "Feed",
                    icon = if (selectedTab == MainTab.FEED) Icons.Filled.Home else Icons.Outlined.Home,
                    isSelected = selectedTab == MainTab.FEED,
                    onClick = { onTabSelected(MainTab.FEED) },
                    testTag = "tab_feed"
                )

                // 2. Explore
                NavItem(
                    label = "Explore",
                    icon = if (selectedTab == MainTab.EXPLORE) Icons.Filled.Explore else Icons.Outlined.Explore,
                    isSelected = selectedTab == MainTab.EXPLORE,
                    onClick = { onTabSelected(MainTab.EXPLORE) },
                    testTag = "tab_explore"
                )

                // 3. New Post Center Accent Pill
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(MessaGradient)
                        .clickable { onTabSelected(MainTab.CREATE) }
                        .testTag("tab_create_post"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "New Post",
                        tint = PureWhite,
                        modifier = Modifier.size(28.dp)
                    )
                }

                // 4. Clips
                NavItem(
                    label = "Clips",
                    icon = if (selectedTab == MainTab.CLIPS) Icons.Filled.PlayCircleFilled else Icons.Outlined.PlayCircle,
                    isSelected = selectedTab == MainTab.CLIPS,
                    onClick = { onTabSelected(MainTab.CLIPS) },
                    testTag = "tab_clips"
                )

                // 5. Profile
                NavItem(
                    label = "Profile",
                    icon = if (selectedTab == MainTab.PROFILE) Icons.Filled.Person else Icons.Outlined.Person,
                    isSelected = selectedTab == MainTab.PROFILE,
                    onClick = { onTabSelected(MainTab.PROFILE) },
                    testTag = "tab_profile"
                )
            }
        }
    }
}

@Composable
private fun NavItem(
    label: String,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Column(
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .testTag(testTag),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (isSelected) NeonCyanBright else TextSecondary,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) PureWhite else TextSecondary
        )
    }
}

@Composable
fun StoryAvatarRing(
    avatarRes: Int?,
    name: String,
    isViewed: Boolean,
    isMe: Boolean = false,
    onClick: () -> Unit
) {
    val ringBrush = if (isViewed) {
        Brush.linearGradient(listOf(DarkSurfaceBorder, DarkSurfaceBorder))
    } else {
        Brush.sweepGradient(listOf(NeonPurple, ElectricBlue, NeonCyan, NeonPurple))
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(76.dp)
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp)
            .testTag("story_item_${name.replace(" ", "_")}")
    ) {
        Box(contentAlignment = Alignment.BottomEnd) {
            Box(
                modifier = Modifier
                    .size(68.dp)
                    .clip(CircleShape)
                    .background(ringBrush)
                    .padding(2.5.dp)
                    .clip(CircleShape)
                    .background(CyberBlack)
                    .padding(2.5.dp)
                    .clip(CircleShape)
            ) {
                if (avatarRes != null) {
                    Image(
                        painter = painterResource(id = avatarRes),
                        contentDescription = name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(DarkSurfaceElevated),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = name.take(1),
                            fontWeight = FontWeight.Bold,
                            color = NeonCyanBright
                        )
                    }
                }
            }

            if (isMe) {
                Box(
                    modifier = Modifier
                        .size(22.dp)
                        .clip(CircleShape)
                        .background(MessaGradient)
                        .border(1.5.dp, CyberBlack, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add Story",
                        tint = PureWhite,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = name,
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
            color = if (isViewed) TextSecondary else PureWhite,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun NeonGradientButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    testTag: String = "neon_button"
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
            .testTag(testTag)
            .height(48.dp)
            .shadow(6.dp, RoundedCornerShape(12.dp), spotColor = NeonPurpleGlow),
        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
        contentPadding = PaddingValues()
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    if (enabled) MessaGradient else Brush.horizontalGradient(listOf(DarkSurfaceBorder, DarkSurfaceBorder)),
                    RoundedCornerShape(12.dp)
                )
                .padding(horizontal = 20.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                if (icon != null) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = PureWhite,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Text(
                    text = text,
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    ),
                    color = PureWhite
                )
            }
        }
    }
}

@Composable
fun DemoModeIndicator(
    isArabic: Boolean = false,
    onDismiss: () -> Unit = {}
) {
    // Demo indicator removed as requested
}

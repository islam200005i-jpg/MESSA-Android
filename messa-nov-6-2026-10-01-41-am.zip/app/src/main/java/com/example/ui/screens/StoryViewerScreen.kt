package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Story
import com.example.data.model.User
import com.example.ui.theme.*

@Composable
fun StoryViewerScreen(
    story: Story,
    currentUser: User,
    isArabic: Boolean = false,
    onClose: () -> Unit,
    onDeleteStory: (String) -> Unit
) {
    BackHandler { onClose() }

    var progress by remember { mutableFloatStateOf(0f) }
    var showViewersSheet by remember { mutableStateOf(false) }
    var replyText by remember { mutableStateOf("") }
    var isLiked by remember { mutableStateOf(false) }

    LaunchedEffect(story.id) {
        progress = 0f
        progress = 1f
    }

    val animatedProgress by animateFloatAsState(
        targetValue = progress,
        animationSpec = tween(durationMillis = 6500, easing = LinearEasing),
        finishedListener = {
            onClose()
        },
        label = "storyProgress"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBlack)
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("story_viewer_screen")
    ) {
        // Story Background Media
        Image(
            painter = painterResource(id = story.mediaRes ?: R.drawable.messa_banner),
            contentDescription = "Story Media",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // Subtle gradient overlay for readability
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            CyberBlack.copy(alpha = 0.75f),
                            Color.Transparent,
                            Color.Transparent,
                            CyberBlack.copy(alpha = 0.85f)
                        )
                    )
                )
        )

        // Top Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            // Segmented Progress Bar
            LinearProgressIndicator(
                progress = { animatedProgress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp)
                    .clip(RoundedCornerShape(2.dp)),
                color = NeonCyanBright,
                trackColor = PureWhite.copy(alpha = 0.3f)
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .border(1.dp, NeonPurple, CircleShape)
                    ) {
                        Image(
                            painter = painterResource(id = story.userAvatarRes ?: R.drawable.messa_logo),
                            contentDescription = story.userName,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = story.userName,
                            fontWeight = FontWeight.Bold,
                            color = PureWhite,
                            fontSize = 14.sp
                        )
                        Text(
                            text = story.timeAgo,
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (story.userId == currentUser.id) {
                        IconButton(
                            onClick = { onDeleteStory(story.id) },
                            modifier = Modifier.size(34.dp)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete Story", tint = ErrorRed)
                        }
                    }

                    IconButton(
                        onClick = onClose,
                        modifier = Modifier.size(34.dp).testTag("close_story_button")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = PureWhite)
                    }
                }
            }
        }

        // Caption & Bottom Reply Bar
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .padding(horizontal = 14.dp, vertical = 16.dp)
        ) {
            if (story.caption.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(CyberBlack.copy(alpha = 0.6f))
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Text(
                        text = story.caption,
                        color = PureWhite,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Viewers count pill for owner
            if (story.userId == currentUser.id) {
                Surface(
                    color = DarkSurfaceElevated.copy(alpha = 0.9f),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .clickable { showViewersSheet = true }
                        .padding(bottom = 10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Visibility, contentDescription = null, tint = NeonCyanBright, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isArabic) "${story.viewersCount} مشاهدة • عرض المشاهدين" else "${story.viewersCount} views • Tap to see viewers",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = PureWhite
                        )
                    }
                }
            }

            // Reply input + Reactions
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = replyText,
                    onValueChange = { replyText = it },
                    placeholder = { Text(if (isArabic) "إرسال رسالة سريعة..." else "Send quick message...", color = TextSecondary, fontSize = 13.sp) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonCyanBright,
                        unfocusedBorderColor = PureWhite.copy(alpha = 0.3f),
                        focusedTextColor = PureWhite,
                        unfocusedTextColor = PureWhite,
                        focusedContainerColor = CyberBlack.copy(alpha = 0.5f),
                        unfocusedContainerColor = CyberBlack.copy(alpha = 0.5f)
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.width(8.dp))

                IconButton(
                    onClick = { isLiked = !isLiked },
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(CyberBlack.copy(alpha = 0.6f))
                ) {
                    Icon(
                        imageVector = if (isLiked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = "Like Story",
                        tint = if (isLiked) LikeRed else PureWhite,
                        modifier = Modifier.size(22.dp)
                    )
                }

                if (replyText.isNotBlank()) {
                    Spacer(modifier = Modifier.width(6.dp))
                    IconButton(
                        onClick = {
                            replyText = ""
                            onClose()
                        },
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(MessaGradient)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "Send",
                            tint = PureWhite,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }

        // Viewers Sheet Dialog
        if (showViewersSheet) {
            AlertDialog(
                onDismissRequest = { showViewersSheet = false },
                confirmButton = {
                    TextButton(onClick = { showViewersSheet = false }) {
                        Text(if (isArabic) "إغلاق" else "Close", color = NeonCyanBright)
                    }
                },
                title = {
                    Text(
                        text = if (isArabic) "مشاهدو القصة (${story.viewersCount})" else "Story Viewers (${story.viewersCount})",
                        color = PureWhite,
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        val sampleViewers = listOf(
                            "Elena Rostova (@elena_quantum)",
                            "CyberLabs (@cyberlabs_ai)",
                            "Tariq Mansoor (@tariq_tech)",
                            "Amina Zahra (@amina_vr)",
                            "Leo Vance (@leo_synth)"
                        )
                        sampleViewers.forEach { viewer ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(NeonPurple.copy(alpha = 0.3f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(viewer.take(1), fontWeight = FontWeight.Bold, color = NeonCyanBright, fontSize = 12.sp)
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(viewer, color = PureWhite, fontSize = 13.sp)
                            }
                        }
                    }
                },
                containerColor = DarkSurfaceElevated
            )
        }
    }
}

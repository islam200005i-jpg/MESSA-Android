package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MainTab
import com.example.ui.MessaViewModel
import com.example.ui.Screen
import com.example.ui.components.DemoModeIndicator
import com.example.ui.components.MessaBottomNav
import com.example.ui.components.MessaTopBar
import com.example.ui.screens.*
import com.example.ui.theme.CyberBlack
import com.example.ui.theme.MessaTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MessaViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val isArabic by viewModel.isArabic.collectAsStateWithLifecycle()
            val layoutDirection = if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr

            CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
                MessaTheme(darkTheme = true) {
                    MessaAppRoot(viewModel = viewModel, isArabic = isArabic)
                }
            }
        }
    }
}

@Composable
fun MessaAppRoot(
    viewModel: MessaViewModel,
    isArabic: Boolean
) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val stories by viewModel.stories.collectAsStateWithLifecycle()
    val posts by viewModel.posts.collectAsStateWithLifecycle()
    val clips by viewModel.clips.collectAsStateWithLifecycle()
    val conversations by viewModel.conversations.collectAsStateWithLifecycle()
    val groups by viewModel.groups.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val isDemoMode by viewModel.isDemoMode.collectAsStateWithLifecycle()
    val isAiGenerating by viewModel.isAiGenerating.collectAsStateWithLifecycle()
    val aiGeneratedDraft by viewModel.aiGeneratedDraft.collectAsStateWithLifecycle()
    val aiSuggestions by viewModel.aiSuggestions.collectAsStateWithLifecycle()

    val unreadMessagesCount = conversations.sumOf { it.unreadCount }
    val unreadNotificationsCount = notifications.count { !it.isRead }

    when (val screen = currentScreen) {
        is Screen.Splash -> {
            SplashScreen()
        }

        is Screen.Auth -> {
            AuthScreen(
                onLoginSuccess = { email -> viewModel.login(email) },
                isArabic = isArabic,
                onLangToggle = { viewModel.toggleLanguage() }
            )
        }

        is Screen.StoryViewer -> {
            StoryViewerScreen(
                story = screen.story,
                currentUser = currentUser,
                isArabic = isArabic,
                onClose = { viewModel.navigateBack() },
                onDeleteStory = { storyId -> viewModel.deleteStory(storyId) }
            )
        }

        is Screen.CreatePost -> {
            CreatePostScreen(
                currentUser = currentUser,
                isArabic = isArabic,
                onBack = { viewModel.navigateBack() },
                onPublish = { content, tags, withMedia ->
                    viewModel.createPost(content, tags, withMedia)
                },
                onAskAi = { topic -> viewModel.askAiAssistant(topic) }
            )
        }

        is Screen.Messages -> {
            MessagesScreen(
                conversations = conversations,
                isArabic = isArabic,
                onBack = { viewModel.navigateBack() },
                onOpenChat = { convId -> viewModel.openChat(convId) }
            )
        }

        is Screen.ChatDetail -> {
            val conversation = conversations.firstOrNull { it.id == screen.conversationId }
            ChatDetailScreen(
                conversation = conversation,
                isArabic = isArabic,
                onBack = { viewModel.navigateBack() },
                onSendMessage = { text, isVoice ->
                    viewModel.sendMessage(screen.conversationId, text, isVoice)
                }
            )
        }

        is Screen.Groups -> {
            GroupsScreen(
                groups = groups,
                isArabic = isArabic,
                onOpenGroup = { groupId -> viewModel.openGroup(groupId) },
                onToggleJoin = { groupId -> viewModel.toggleJoinGroup(groupId) },
                onCreateGroup = { name, desc, cat, priv -> viewModel.createGroup(name, desc, cat, priv) },
                onBack = { viewModel.navigateBack() }
            )
        }

        is Screen.GroupDetail -> {
            val group = groups.firstOrNull { it.id == screen.groupId }
            GroupDetailScreen(
                group = group,
                currentUser = currentUser,
                isArabic = isArabic,
                onBack = { viewModel.navigateBack() },
                onToggleJoin = { groupId -> viewModel.toggleJoinGroup(groupId) }
            )
        }

        is Screen.MessaAi -> {
            MessaAiScreen(
                aiSuggestions = aiSuggestions,
                isGenerating = isAiGenerating,
                generatedDraft = aiGeneratedDraft,
                isArabic = isArabic,
                onBack = { viewModel.navigateBack() },
                onGenerate = { topic -> viewModel.askAiAssistant(topic) },
                onApplyToPost = { content, tags ->
                    viewModel.createPost(content, tags, true)
                }
            )
        }

        is Screen.Notifications -> {
            NotificationsScreen(
                notifications = notifications,
                isArabic = isArabic,
                onBack = { viewModel.navigateBack() }
            )
        }

        is Screen.Settings -> {
            SettingsScreen(
                user = currentUser,
                isArabic = isArabic,
                onBack = { viewModel.navigateBack() },
                onUpdateProfile = { name, username, bio ->
                    viewModel.updateProfile(name, username, bio)
                },
                onToggleLanguage = { viewModel.toggleLanguage() },
                onLogout = { viewModel.logout() }
            )
        }

        is Screen.Main -> {
            BackHandler(enabled = selectedTab != MainTab.FEED) {
                viewModel.selectTab(MainTab.FEED)
            }

            Scaffold(
                topBar = {
                    Column {
                        MessaTopBar(
                            title = "MESSA",
                            subtitle = null,
                            unreadMessages = unreadMessagesCount,
                            unreadNotifications = unreadNotificationsCount,
                            isArabic = isArabic,
                            onMessagesClick = { viewModel.navigateTo(Screen.Messages) },
                            onNotificationsClick = { viewModel.navigateTo(Screen.Notifications) },
                            onAiClick = { viewModel.navigateTo(Screen.MessaAi) },
                            onSearchClick = { viewModel.selectTab(MainTab.EXPLORE) },
                            onLangToggle = { viewModel.toggleLanguage() }
                        )
                    }
                },
                bottomBar = {
                    MessaBottomNav(
                        selectedTab = selectedTab,
                        onTabSelected = { tab -> viewModel.selectTab(tab) },
                        modifier = Modifier.testTag("messa_bottom_nav")
                    )
                },
                containerColor = CyberBlack,
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("main_screen")
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .background(CyberBlack)
                ) {
                    when (selectedTab) {
                        MainTab.FEED -> {
                            FeedScreen(
                                currentUser = currentUser,
                                stories = stories,
                                posts = posts,
                                isArabic = isArabic,
                                onStoryClick = { story -> viewModel.openStory(story) },
                                onAddStoryClick = {
                                    viewModel.addStory("New story from Sarah! 🚀⚡")
                                },
                                onNewPostClick = { viewModel.navigateTo(Screen.CreatePost) },
                                onLikePost = { id -> viewModel.toggleLikePost(id) },
                                onSavePost = { id -> viewModel.toggleSavePost(id) },
                                onAddComment = { id, text -> viewModel.addComment(id, text) },
                                onFollowUser = { id -> viewModel.toggleFollowUser(id) },
                                onDeletePost = { id -> viewModel.deletePost(id) }
                            )
                        }

                        MainTab.EXPLORE -> {
                            ExploreScreen(
                                posts = posts,
                                groups = groups,
                                isArabic = isArabic,
                                onOpenGroup = { id -> viewModel.openGroup(id) },
                                onFollowUser = { id -> viewModel.toggleFollowUser(id) },
                                onOpenPost = { /* Open post */ }
                            )
                        }

                        MainTab.CLIPS -> {
                            ClipsScreen(
                                clips = clips,
                                isArabic = isArabic,
                                onLikeClip = { id -> viewModel.toggleLikeClip(id) },
                                onFollowUser = { id -> viewModel.toggleFollowUser(id) }
                            )
                        }

                        MainTab.PROFILE -> {
                            ProfileScreen(
                                user = currentUser,
                                posts = posts,
                                isArabic = isArabic,
                                onUpdateProfile = { name, username, bio ->
                                    viewModel.updateProfile(name, username, bio)
                                },
                                onSettingsClick = { viewModel.navigateTo(Screen.Settings) },
                                onLogout = { viewModel.logout() }
                            )
                        }

                        MainTab.CREATE -> {
                            // Handled by Screen.CreatePost
                        }
                    }
                }
            }
        }
    }
}

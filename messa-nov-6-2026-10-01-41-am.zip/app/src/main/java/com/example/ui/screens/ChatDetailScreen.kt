package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Conversation
import com.example.data.model.Message
import com.example.ui.theme.*

@Composable
fun ChatDetailScreen(
    conversation: Conversation?,
    isArabic: Boolean = false,
    onBack: () -> Unit,
    onSendMessage: (String, Boolean) -> Unit
) {
    BackHandler { onBack() }

    var inputText by remember { mutableStateOf("") }
    var isRecordingVoice by remember { mutableStateOf(false) }

    if (conversation == null) {
        Box(modifier = Modifier.fillMaxSize().background(CyberBlack), contentAlignment = Alignment.Center) {
            Text(if (isArabic) "المحادثة غير متوفرة" else "Conversation not found", color = TextSecondary)
        }
        return
    }

    Scaffold(
        topBar = {
            Surface(
                color = CyberBlack,
                modifier = Modifier.statusBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onBack, modifier = Modifier.testTag("chat_back_button")) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = PureWhite)
                        }

                        Box(contentAlignment = Alignment.BottomEnd) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .border(1.dp, NeonPurple, CircleShape)
                            ) {
                                Image(
                                    painter = painterResource(id = conversation.user.avatarRes ?: R.drawable.messa_logo),
                                    contentDescription = conversation.user.name,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            if (conversation.user.isOnline) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(SuccessGreen)
                                        .border(1.5.dp, CyberBlack, CircleShape)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            Text(
                                text = conversation.user.name,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = PureWhite
                            )
                            Text(
                                text = if (conversation.user.isOnline) (if (isArabic) "متصل الآن ⚡" else "Online now ⚡") else (if (isArabic) "غير متصل" else "Offline"),
                                fontSize = 11.sp,
                                color = if (conversation.user.isOnline) SuccessGreen else TextTertiary
                            )
                        }
                    }

                    // Voice / Video Call Quick Actions
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { /* Call */ }) {
                            Icon(Icons.Default.Call, contentDescription = "Voice Call", tint = PureWhite)
                        }
                        IconButton(onClick = { /* Video */ }) {
                            Icon(Icons.Default.Videocam, contentDescription = "Video Call", tint = NeonCyanBright)
                        }
                    }
                }
            }
        },
        bottomBar = {
            Surface(
                color = DarkSurface,
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .imePadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            // Quick media attach simulation
                            onSendMessage("Shared photo from MESSA Gallery", false)
                        },
                        modifier = Modifier.size(38.dp)
                    ) {
                        Icon(Icons.Default.AddPhotoAlternate, contentDescription = "Photo", tint = NeonCyanBright)
                    }

                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        placeholder = { Text(if (isArabic) "اكتب رسالة مشفرة..." else "Type encrypted message...", fontSize = 13.sp, color = TextSecondary) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("chat_input_field"),
                        shape = RoundedCornerShape(22.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyanBright,
                            unfocusedBorderColor = DarkSurfaceBorder,
                            focusedTextColor = PureWhite,
                            unfocusedTextColor = PureWhite,
                            focusedContainerColor = CyberBlack,
                            unfocusedContainerColor = CyberBlack
                        ),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    if (inputText.isNotBlank()) {
                        IconButton(
                            onClick = {
                                onSendMessage(inputText, false)
                                inputText = ""
                            },
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(MessaGradient)
                                .testTag("chat_send_button")
                        ) {
                            Icon(Icons.Default.Send, contentDescription = "Send", tint = PureWhite, modifier = Modifier.size(18.dp))
                        }
                    } else {
                        // Voice note record button
                        IconButton(
                            onClick = {
                                isRecordingVoice = !isRecordingVoice
                                onSendMessage("Voice Note (0:15) 🎙️", true)
                            },
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(if (isRecordingVoice) ErrorRed else NeonPurple)
                                .testTag("chat_voice_button")
                        ) {
                            Icon(Icons.Default.Mic, contentDescription = "Voice Note", tint = PureWhite, modifier = Modifier.size(20.dp))
                        }
                    }
                }
            }
        },
        containerColor = CyberBlack
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 14.dp, vertical = 8.dp),
            reverseLayout = false
        ) {
            items(conversation.messages, key = { it.id }) { msg ->
                ChatMessageBubble(msg = msg, isArabic = isArabic)
            }
        }
    }
}

@Composable
private fun ChatMessageBubble(msg: Message, isArabic: Boolean) {
    val alignment = if (msg.isSentByMe) Alignment.CenterEnd else Alignment.CenterStart
    val bubbleBrush = if (msg.isSentByMe) {
        MessaGradient
    } else {
        Brush.linearGradient(listOf(DarkSurfaceElevated, DarkSurface))
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        contentAlignment = alignment
    ) {
        Column(
            horizontalAlignment = if (msg.isSentByMe) Alignment.End else Alignment.Start,
            modifier = Modifier.widthIn(max = 280.dp)
        ) {
            Box(
                modifier = Modifier
                    .clip(
                        RoundedCornerShape(
                            topStart = 16.dp,
                            topEnd = 16.dp,
                            bottomStart = if (msg.isSentByMe) 16.dp else 2.dp,
                            bottomEnd = if (msg.isSentByMe) 2.dp else 16.dp
                        )
                    )
                    .background(bubbleBrush)
                    .border(
                        0.5.dp,
                        if (msg.isSentByMe) NeonCyanBright.copy(alpha = 0.5f) else DarkSurfaceBorder,
                        RoundedCornerShape(16.dp)
                    )
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                if (msg.isVoice) {
                    // Audio Voice Note Waveform representation
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(PureWhite.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = "Play Voice", tint = PureWhite, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val heights = listOf(8, 16, 24, 12, 28, 18, 10, 22, 14, 8)
                                heights.forEach { h ->
                                    Box(
                                        modifier = Modifier
                                            .width(3.dp)
                                            .height(h.dp)
                                            .clip(RoundedCornerShape(1.dp))
                                            .background(PureWhite)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "0:15",
                                fontSize = 10.sp,
                                color = PureWhite.copy(alpha = 0.8f)
                            )
                        }
                    }
                } else {
                    Text(
                        text = msg.text,
                        color = PureWhite,
                        fontSize = 14.sp,
                        lineHeight = 20.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(2.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = msg.time,
                    fontSize = 10.sp,
                    color = TextTertiary
                )
                if (msg.isSentByMe) {
                    Icon(
                        imageVector = if (msg.isRead) Icons.Default.DoneAll else Icons.Default.Done,
                        contentDescription = "Read status",
                        tint = if (msg.isRead) NeonCyanBright else TextTertiary,
                        modifier = Modifier.size(13.dp)
                    )
                }
            }
        }
    }
}
